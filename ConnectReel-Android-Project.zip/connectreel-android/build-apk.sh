#!/usr/bin/env bash
set -e
npm install
if [ ! -d android ]; then npm run android:add; fi
npm run android:build
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
