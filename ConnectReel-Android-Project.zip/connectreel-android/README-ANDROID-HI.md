# ConnectReel — Android App

Ye project tumhare original ConnectReel React/Vite app ko Android APK me package karne ke liye prepare kiya gaya hai.

## APK banane ka easiest tareeka

1. Node.js 20+ install karo.
2. Android Studio + Android SDK install karo.
3. Is folder me terminal kholo.
4. Run karo:

```bash
npm install
npm run android:add
npm run android:build
```

Debug APK yahan milega:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Android Studio se

```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```

Android Studio me **Build > Build APK(s)** select karo.

## App details

- App name: ConnectReel
- Package ID: com.connectreel.app
- Web UI: React + Vite
- Android wrapper: Capacitor

### Note

Original project ka `server.ts` development/demo backend hai. Capacitor APK frontend ko bundle karta hai; server ko alag hosting/backend ki zarurat tabhi hogi jab future me real authentication, database, calling, payments ya uploads connect karne ho.
