import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // REST API Endpoints for ConnectReel backend
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      app: 'ConnectReel',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        mediaStreaming: 'ready',
        paymentsGateway: 'active (UPI/Cards)',
        realtimeSignaling: 'operational',
      },
    });
  });

  // Auth endpoint simulation
  app.post('/api/auth/otp/send', (req: Request, res: Response) => {
    const { target } = req.body;
    res.json({
      success: true,
      message: `OTP sent to ${target}`,
      testCode: '582419',
    });
  });

  app.post('/api/auth/otp/verify', (req: Request, res: Response) => {
    const { code } = req.body;
    if (code === '582419' || code?.length === 6) {
      res.json({
        success: true,
        token: 'auth_jwt_test_token_2026',
        user: { id: 'usr_me', username: 'karan_creates', role: 'creator' },
      });
    } else {
      res.status(400).json({ success: false, error: 'Invalid OTP code' });
    }
  });

  // Payments verification endpoint
  app.post('/api/payments/verify', (req: Request, res: Response) => {
    const { amountINR, paymentMethod } = req.body;
    const txId = 'PAY_' + Math.random().toString(36).substring(2, 9).toUpperCase();
    res.json({
      success: true,
      transactionId: txId,
      amountINR,
      paymentMethod,
      settledAt: new Date().toISOString(),
    });
  });

  // Media upload simulation
  app.post('/api/media/upload', (req: Request, res: Response) => {
    res.json({
      success: true,
      url: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=600&auto=format&fit=crop&q=80',
      optimizedBitrate: '3.5Mbps',
    });
  });

  // Mount Vite middlewares in development
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`ConnectReel full-stack engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
