import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { SearchModal } from './components/common/SearchModal';
import { HomeFeed } from './components/feed/HomeFeed';
import { ReelsViewer } from './components/reels/ReelsViewer';
import { CreateModal } from './components/create/CreateModal';
import { ChatList } from './components/chat/ChatList';
import { ChatRoom } from './components/chat/ChatRoom';
import { CallingModal } from './components/call/CallingModal';
import { CommunitiesHub } from './components/communities/CommunitiesHub';
import { ProfileView } from './components/profile/ProfileView';
import { PaymentGatewayModal } from './components/monetization/PaymentGatewayModal';
import { WalletModal } from './components/monetization/WalletModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { OnboardingFlow } from './components/onboarding/OnboardingFlow';

const MainAppContent: React.FC = () => {
  const { 
    currentTab, 
    activeConversation, 
    setActiveConversation, 
    isMobileFrame 
  } = useApp();

  return (
    <div className={`min-h-screen flex flex-col items-center justify-start ${isMobileFrame ? 'bg-neutral-900 py-6' : 'bg-neutral-950'}`}>
      
      {/* Container: either smartphone frame or responsive container */}
      <div
        className={`w-full flex flex-col relative transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[420px] h-[880px] bg-neutral-950 rounded-[44px] border-[10px] border-neutral-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden ring-1 ring-white/10'
            : 'max-w-xl min-h-screen bg-neutral-950 border-x border-neutral-900'
        }`}
      >
        {/* Smartphone Dynamic Island Notch (visible in device frame mode) */}
        {isMobileFrame && (
          <div className="w-full flex justify-center pt-2 pb-1 shrink-0 bg-neutral-950 z-50">
            <div className="w-24 h-4 rounded-full bg-neutral-900 flex items-center justify-end px-2">
              <span className="w-2 h-2 rounded-full bg-neutral-800" />
            </div>
          </div>
        )}

        {/* Global Top App Bar (Hidden in Reels mode for full immersion) */}
        {currentTab !== 'reels' && !activeConversation && (
          <Header />
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto no-scrollbar relative">
          {currentTab === 'home' && <HomeFeed />}
          {currentTab === 'reels' && <ReelsViewer />}
          {currentTab === 'communities' && <CommunitiesHub />}
          {currentTab === 'chats' && (
            activeConversation ? (
              <ChatRoom
                conversation={activeConversation}
                onBack={() => setActiveConversation(null)}
              />
            ) : (
              <ChatList onSelectConversation={setActiveConversation} />
            )
          )}
          {currentTab === 'profile' && <ProfileView />}
        </main>

        {/* 5-Destination Bottom Navigation (Hidden when inside an active chat room) */}
        {!activeConversation && <BottomNav />}

        {/* All Interactive Drawers & Overlays */}
        <SearchModal />
        <CreateModal />
        <PaymentGatewayModal />
        <WalletModal />
        <CallingModal />
        <AdminDashboard />
        <OnboardingFlow />

      </div>

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
