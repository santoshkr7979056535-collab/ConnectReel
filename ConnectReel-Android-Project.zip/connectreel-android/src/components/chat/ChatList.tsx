import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  Users, 
  Phone, 
  Video, 
  MessageSquare, 
  Check, 
  CheckCheck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  PhoneMissed,
  Clock,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Conversation, User, CallRecord } from '../../types';

interface ChatListProps {
  onSelectConversation: (c: Conversation) => void;
}

export const ChatList: React.FC<ChatListProps> = ({ onSelectConversation }) => {
  const { 
    conversations, 
    calls, 
    currentUser, 
    allUsers, 
    createGroup, 
    startCall 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'chats' | 'calls'>('chats');
  const [searchQuery, setSearchQuery] = useState('');
  const [newGroupOpen, setNewGroupOpen] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupDesc, setGroupDesc] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    if (!searchQuery) return true;
    const name = c.isGroup
      ? c.name
      : c.members.find((m) => m.id !== currentUser.id)?.name || '';
    return name?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim() || selectedUserIds.length === 0) return;

    const newId = createGroup(groupName.trim(), groupDesc.trim(), selectedUserIds);
    setNewGroupOpen(false);
    setGroupName('');
    setGroupDesc('');
    setSelectedUserIds([]);

    const created = conversations.find((c) => c.id === newId);
    if (created) onSelectConversation(created);
  };

  const toggleSelectUser = (id: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="w-full max-w-xl mx-auto h-[calc(100vh-3.5rem)] flex flex-col pb-20">
      
      {/* Top Header & Search */}
      <div className="p-4 border-b border-neutral-800 space-y-3 bg-neutral-950/80 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Direct Messages & Calls</h2>
          <button
            onClick={() => setNewGroupOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30 hover:bg-rose-500 hover:text-white transition-colors"
          >
            <Users className="w-3.5 h-3.5" />
            <span>New Group</span>
          </button>
        </div>

        {/* Tab Switcher: Chats vs Calls */}
        <div className="flex items-center gap-2 p-1 bg-neutral-900 rounded-2xl border border-neutral-800">
          <button
            onClick={() => setActiveTab('chats')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'chats' ? 'bg-rose-500 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Chats
          </button>
          <button
            onClick={() => setActiveTab('calls')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'calls' ? 'bg-rose-500 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Calls History ({calls.length})
          </button>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversations, friends, groups..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
          />
        </div>
      </div>

      {/* Tab 1: Chats View */}
      {activeTab === 'chats' && (
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-900 no-scrollbar">
          {filteredConversations.map((conv) => {
            const otherUser = conv.members.find((m) => m.id !== currentUser.id) || conv.members[0];
            const title = conv.isGroup ? conv.name : otherUser?.name;
            const avatar = conv.isGroup ? conv.avatar : otherUser?.avatar;
            const isOnline = otherUser?.status === 'online';

            return (
              <div
                key={conv.id}
                onClick={() => onSelectConversation(conv)}
                className="flex items-center justify-between p-3.5 hover:bg-neutral-900/60 cursor-pointer transition-colors active:bg-neutral-900"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={avatar}
                      alt={title}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-neutral-800"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    {!conv.isGroup && (
                      <span
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-neutral-950 ${
                          isOnline ? 'bg-emerald-500' : 'bg-neutral-500'
                        }`}
                      />
                    )}
                  </div>

                  <div className="truncate text-left">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-neutral-100 truncate">{title}</span>
                      {conv.isGroup && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 font-semibold">
                          Group
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-neutral-400 truncate mt-0.5">
                      {conv.lastMessage?.senderId === currentUser.id && (
                        <span>
                          {conv.lastMessage.status === 'seen' ? (
                            <CheckCheck className="w-3.5 h-3.5 text-blue-400 inline" />
                          ) : (
                            <Check className="w-3.5 h-3.5 text-neutral-500 inline" />
                          )}
                        </span>
                      )}
                      <p className="truncate">
                        {conv.lastMessage?.isDeleted
                          ? 'This message was deleted'
                          : conv.lastMessage?.content || 'No messages yet'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1.5 shrink-0 ml-2">
                  <span className="text-[10px] text-neutral-500 font-medium">
                    {conv.updatedAt}
                  </span>
                  {conv.unreadCount > 0 && (
                    <span className="px-1.5 py-0.5 min-w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Calls History */}
      {activeTab === 'calls' && (
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-900 no-scrollbar">
          {calls.map((call) => {
            const isMissed = call.status === 'missed';
            return (
              <div
                key={call.id}
                className="flex items-center justify-between p-3.5 hover:bg-neutral-900/60 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={call.partner.avatar}
                    alt={call.partner.name}
                    className="w-11 h-11 rounded-full object-cover ring-2 ring-neutral-800"
                  />
                  <div className="text-left truncate">
                    <span className={`text-sm font-bold ${isMissed ? 'text-rose-400' : 'text-neutral-100'}`}>
                      {call.partner.name}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-0.5">
                      {call.direction === 'outgoing' ? (
                        <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                      ) : isMissed ? (
                        <PhoneMissed className="w-3 h-3 text-rose-500" />
                      ) : (
                        <ArrowDownLeft className="w-3 h-3 text-blue-400" />
                      )}
                      <span>{call.createdAt}</span>
                      {call.durationSeconds > 0 && (
                        <span>· {Math.floor(call.durationSeconds / 60)}m {call.durationSeconds % 60}s</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => startCall(call.partner, 'voice')}
                    className="p-2.5 rounded-full bg-neutral-900 hover:bg-emerald-500/20 text-neutral-300 hover:text-emerald-400 transition-colors"
                    title="Audio call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => startCall(call.partner, 'video')}
                    className="p-2.5 rounded-full bg-neutral-900 hover:bg-rose-500/20 text-neutral-300 hover:text-rose-400 transition-colors"
                    title="Video call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Group Modal */}
      {newGroupOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Create New Group Community</h3>
            <form onSubmit={handleCreateGroupSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400">Group Name</label>
                <input
                  type="text"
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  placeholder="e.g. Mumbai Reel Creators"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500 mt-1"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400">Description</label>
                <input
                  type="text"
                  value={groupDesc}
                  onChange={(e) => setGroupDesc(e.target.value)}
                  placeholder="Describe the group purpose..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500 mt-1"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 mb-1 block">Select Members ({selectedUserIds.length})</label>
                <div className="max-h-40 overflow-y-auto space-y-1.5 no-scrollbar border border-neutral-800 rounded-xl p-2 bg-neutral-950">
                  {allUsers
                    .filter((u) => u.id !== currentUser.id)
                    .map((user) => {
                      const isSelected = selectedUserIds.includes(user.id);
                      return (
                        <div
                          key={user.id}
                          onClick={() => toggleSelectUser(user.id)}
                          className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors ${
                            isSelected ? 'bg-rose-500/20 text-white' : 'hover:bg-neutral-900 text-neutral-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <img src={user.avatar} alt={user.name} className="w-7 h-7 rounded-full object-cover" />
                            <span className="text-xs font-semibold">{user.name}</span>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-rose-400" />}
                        </div>
                      );
                    })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setNewGroupOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!groupName.trim() || selectedUserIds.length === 0}
                  className="px-4 py-1.5 rounded-xl bg-rose-500 text-white text-xs font-bold hover:bg-rose-600 disabled:opacity-40"
                >
                  Create Group
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
