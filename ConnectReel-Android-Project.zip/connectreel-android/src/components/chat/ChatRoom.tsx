import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  Send, 
  Paperclip, 
  Mic, 
  MicOff, 
  Smile, 
  Check, 
  CheckCheck, 
  Trash2, 
  CornerUpLeft, 
  Copy, 
  FileText, 
  Image as ImageIcon,
  Play,
  Pause
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Conversation, ChatMessage, User } from '../../types';
import { uploadMediaFile } from '../../services/api';

interface ChatRoomProps {
  conversation: Conversation;
  onBack: () => void;
}

export const ChatRoom: React.FC<ChatRoomProps> = ({ conversation, onBack }) => {
  const { 
    currentUser, 
    sendMessage, 
    deleteMessage, 
    reactToMessage, 
    startCall 
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [peerTyping, setPeerTyping] = useState(false);
  const [replyTarget, setReplyTarget] = useState<ChatMessage | null>(null);
  const [selectedMsgForMenu, setSelectedMsgForMenu] = useState<ChatMessage | null>(null);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceDuration, setVoiceDuration] = useState(0);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Local message thread initialized from lastMessage or conversation seed
  const [messageList, setMessageList] = useState<ChatMessage[]>([
    {
      id: 'm_seed_1',
      conversationId: conversation.id,
      senderId: conversation.members[1]?.id || 'usr_1',
      senderName: conversation.members[1]?.name || 'Creator',
      senderAvatar: conversation.members[1]?.avatar || '',
      type: 'text',
      content: conversation.lastMessage?.content || 'Hey! Did you check out the new Reel draft?',
      createdAt: '10:14 AM',
      status: 'seen',
      reactions: { [currentUser.id]: '🔥' },
    },
    {
      id: 'm_seed_2',
      conversationId: conversation.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type: 'text',
      content: 'Yes! The transitions and color grade look super polished. Let us jump on a quick call if you have 5 minutes.',
      createdAt: '10:16 AM',
      status: 'seen',
      reactions: {},
    },
    {
      id: 'm_seed_3',
      conversationId: conversation.id,
      senderId: conversation.members[1]?.id || 'usr_1',
      senderName: conversation.members[1]?.name || 'Creator',
      senderAvatar: conversation.members[1]?.avatar || '',
      type: 'voice',
      content: 'Voice note (0:18)',
      duration: 18,
      createdAt: '10:18 AM',
      status: 'seen',
      reactions: { [currentUser.id]: '👍' },
    }
  ]);

  const partner: User = conversation.members.find((m) => m.id !== currentUser.id) || conversation.members[0];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messageList, peerTyping]);

  // Handle voice recording timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecordingVoice) {
      timer = setInterval(() => setVoiceDuration((prev) => prev + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [isRecordingVoice]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMsg: ChatMessage = {
      id: 'm_' + Date.now(),
      conversationId: conversation.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type: 'text',
      content: inputMessage.trim(),
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      replyTo: replyTarget
        ? {
            id: replyTarget.id,
            senderName: replyTarget.senderName,
            text: replyTarget.content,
          }
        : undefined,
      reactions: {},
    };

    setMessageList((prev) => [...prev, newMsg]);
    sendMessage(conversation.id, inputMessage.trim(), 'text', undefined, newMsg.replyTo);

    setInputMessage('');
    setReplyTarget(null);
    setShowEmojiPicker(false);

    // Simulate delivered tick after 1s and peer typing after 2s
    setTimeout(() => {
      setMessageList((prev) =>
        prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'delivered' } : m))
      );
      setPeerTyping(true);
    }, 1200);

    setTimeout(() => {
      setPeerTyping(false);
      setMessageList((prev) =>
        prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'seen' } : m))
      );
      // Peer simulated reply
      const simulatedReplies = [
        'Awesome, totally agree! 🚀',
        'Just reviewed the analytics, views are spiking in Delhi & Mumbai!',
        'Got it! Dropping the stems and LUT preset in our group chat.',
        'Sounds great, let us connect again in the evening 👍'
      ];
      const peerMsg: ChatMessage = {
        id: 'm_peer_' + Date.now(),
        conversationId: conversation.id,
        senderId: partner.id,
        senderName: partner.name,
        senderAvatar: partner.avatar,
        type: 'text',
        content: simulatedReplies[Math.floor(Math.random() * simulatedReplies.length)],
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'delivered',
        reactions: {},
      };
      setMessageList((prev) => [...prev, peerMsg]);
    }, 3000);
  };

  const handleSendVoiceNote = () => {
    setIsRecordingVoice(false);
    const newMsg: ChatMessage = {
      id: 'm_voice_' + Date.now(),
      conversationId: conversation.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type: 'voice',
      content: `Voice message (${voiceDuration}s)`,
      duration: voiceDuration || 4,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      reactions: {},
    };
    setMessageList((prev) => [...prev, newMsg]);
    setVoiceDuration(0);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const { url, size, type } = await uploadMediaFile(file);

      const newMsg: ChatMessage = {
        id: 'm_file_' + Date.now(),
        conversationId: conversation.id,
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        type: type === 'image' ? 'image' : type === 'video' ? 'video' : 'doc',
        content: file.name,
        mediaUrl: url,
        fileName: file.name,
        fileSize: size,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'sent',
        reactions: {},
      };
      setMessageList((prev) => [...prev, newMsg]);
    }
  };

  const handleReact = (msgId: string, emoji: string) => {
    setMessageList((prev) =>
      prev.map((m) => {
        if (m.id === msgId) {
          return {
            ...m,
            reactions: {
              ...m.reactions,
              [currentUser.id]: emoji,
            },
          };
        }
        return m;
      })
    );
    setSelectedMsgForMenu(null);
  };

  const handleDeleteMsg = (msgId: string) => {
    setMessageList((prev) =>
      prev.map((m) =>
        m.id === msgId ? { ...m, isDeleted: true, content: 'This message was deleted' } : m
      )
    );
    deleteMessage(conversation.id, msgId);
    setSelectedMsgForMenu(null);
  };

  return (
    <div className="w-full max-w-xl mx-auto h-[calc(100vh-3.5rem)] flex flex-col bg-neutral-950 relative">
      
      {/* Top Header */}
      <div className="h-14 px-3 flex items-center justify-between border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="p-1.5 -ml-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <img
            src={conversation.isGroup ? conversation.avatar : partner.avatar}
            alt="Avatar"
            className="w-9 h-9 rounded-full object-cover ring-2 ring-neutral-700"
          />

          <div className="text-left">
            <span className="text-xs font-bold text-white line-clamp-1">
              {conversation.isGroup ? conversation.name : partner.name}
            </span>
            <span className="text-[10px] text-emerald-400 block font-medium">
              {peerTyping ? 'typing...' : conversation.isGroup ? `${conversation.members.length} members` : partner.status === 'online' ? 'Active now' : 'Last seen 2h ago'}
            </span>
          </div>
        </div>

        {/* Action icons: Voice Call & Video Call */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => startCall(partner, 'voice')}
            className="p-2 text-neutral-300 hover:text-emerald-400 hover:bg-neutral-800 rounded-lg transition-colors"
            title="Start Voice Call"
          >
            <Phone className="w-4 h-4" />
          </button>
          <button
            onClick={() => startCall(partner, 'video')}
            className="p-2 text-neutral-300 hover:text-rose-400 hover:bg-neutral-800 rounded-lg transition-colors"
            title="Start Video Call"
          >
            <Video className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar text-xs">
        {messageList.map((msg) => {
          const isMine = msg.senderId === currentUser.id;

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMine ? 'items-end' : 'items-start'} group`}
            >
              {/* Reply quote banner if present */}
              {msg.replyTo && (
                <div className={`text-[10px] px-2.5 py-1 mb-0.5 rounded-lg bg-neutral-900 border-l-2 border-rose-500 text-neutral-400 max-w-[75%]`}>
                  <span className="font-semibold text-rose-400">{msg.replyTo.senderName}: </span>
                  <span className="truncate">{msg.replyTo.text}</span>
                </div>
              )}

              {/* Message Bubble Container */}
              <div className="relative flex items-center gap-1">
                
                {/* Quick action buttons on hover/long-press */}
                <div className={`opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity ${isMine ? 'order-first' : 'order-last'}`}>
                  <button
                    onClick={() => setReplyTarget(msg)}
                    className="p-1 rounded-full bg-neutral-800 text-neutral-400 hover:text-white"
                    title="Reply"
                  >
                    <CornerUpLeft className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => setSelectedMsgForMenu(selectedMsgForMenu?.id === msg.id ? null : msg)}
                    className="p-1 rounded-full bg-neutral-800 text-neutral-400 hover:text-white"
                    title="Reactions & Options"
                  >
                    <Smile className="w-3 h-3" />
                  </button>
                  {isMine && (
                    <button
                      onClick={() => handleDeleteMsg(msg.id)}
                      className="p-1 rounded-full bg-neutral-800 text-neutral-400 hover:text-rose-400"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {/* The Bubble */}
                <div
                  className={`p-3 rounded-2xl max-w-[80vw] sm:max-w-md shadow-md ${
                    msg.isDeleted
                      ? 'bg-neutral-900/60 text-neutral-500 italic border border-neutral-800'
                      : isMine
                      ? 'bg-gradient-to-tr from-violet-600 to-rose-600 text-white rounded-br-none'
                      : 'bg-neutral-900 text-neutral-200 border border-neutral-800 rounded-bl-none'
                  }`}
                >
                  {/* Media Content */}
                  {msg.type === 'image' && msg.mediaUrl && (
                    <img
                      src={msg.mediaUrl}
                      alt="Attachment"
                      className="rounded-xl max-h-56 w-full object-cover mb-1.5"
                    />
                  )}

                  {msg.type === 'video' && msg.mediaUrl && (
                    <video
                      src={msg.mediaUrl}
                      controls
                      className="rounded-xl max-h-56 w-full object-cover mb-1.5"
                    />
                  )}

                  {/* Voice Note Player */}
                  {msg.type === 'voice' && (
                    <div className="flex items-center gap-3 py-1 min-w-[160px]">
                      <button className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors">
                        <Play className="w-3.5 h-3.5 fill-white" />
                      </button>
                      <div className="flex-1 space-y-1">
                        {/* Audio waveform visualization bars */}
                        <div className="flex items-center gap-0.5 h-4">
                          {[40, 70, 90, 30, 80, 50, 90, 60, 40, 80, 100, 30, 60, 90].map((h, i) => (
                            <span
                              key={i}
                              style={{ height: `${h}%` }}
                              className="w-1 bg-white/80 rounded-full"
                            />
                          ))}
                        </div>
                        <span className="text-[10px] opacity-80 tabular-nums">0:{msg.duration || 15}</span>
                      </div>
                    </div>
                  )}

                  {/* Document Attachment */}
                  {msg.type === 'doc' && (
                    <div className="flex items-center gap-2 p-2 bg-black/20 rounded-xl mb-1">
                      <FileText className="w-5 h-5 text-rose-300" />
                      <div className="truncate">
                        <p className="font-semibold truncate">{msg.fileName || 'document.pdf'}</p>
                        <span className="text-[10px] opacity-80">{msg.fileSize || '1.2 MB'}</span>
                      </div>
                    </div>
                  )}

                  {/* Message Text */}
                  {msg.type !== 'voice' && (
                    <p className="leading-relaxed break-words">{msg.content}</p>
                  )}

                  {/* Timestamp & Status checkmarks */}
                  <div className="flex items-center justify-end gap-1 text-[9px] opacity-75 mt-1 select-none">
                    <span>{msg.createdAt}</span>
                    {isMine && !msg.isDeleted && (
                      <span>
                        {msg.status === 'seen' ? (
                          <CheckCheck className="w-3 h-3 text-cyan-300" />
                        ) : msg.status === 'delivered' ? (
                          <CheckCheck className="w-3 h-3 text-white/70" />
                        ) : (
                          <Check className="w-3 h-3 text-white/50" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Message Reactions Badge */}
              {Object.keys(msg.reactions).length > 0 && (
                <div className="flex items-center gap-0.5 -mt-2 bg-neutral-900 border border-neutral-800 rounded-full px-1.5 py-0.5 shadow-md">
                  {Object.values(msg.reactions).map((emoji, idx) => (
                    <span key={idx} className="text-xs">{emoji}</span>
                  ))}
                </div>
              )}

              {/* Reaction Picker floating popover */}
              {selectedMsgForMenu?.id === msg.id && (
                <div className="p-1 bg-neutral-900 border border-neutral-700 rounded-full shadow-2xl flex items-center gap-1.5 mt-1 z-20">
                  {['❤️', '🔥', '👍', '😂', '😮', '😢'].map((em) => (
                    <button
                      key={em}
                      onClick={() => handleReact(msg.id, em)}
                      className="text-base hover:scale-125 transition-transform p-1"
                    >
                      {em}
                    </button>
                  ))}
                </div>
              )}

            </div>
          );
        })}

        {/* Peer Typing Indicator Bubble */}
        {peerTyping && (
          <div className="flex items-center gap-1.5 p-3 rounded-2xl bg-neutral-900 border border-neutral-800 w-20 text-neutral-400">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce" />
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce [animation-delay:0.2s]" />
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce [animation-delay:0.4s]" />
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Reply target banner above input */}
      {replyTarget && (
        <div className="p-2 px-4 bg-neutral-900 border-t border-neutral-800 flex items-center justify-between text-xs">
          <div className="truncate">
            <span className="text-rose-400 font-bold">Replying to {replyTarget.senderName}:</span>
            <p className="text-neutral-400 truncate">{replyTarget.content}</p>
          </div>
          <button onClick={() => setReplyTarget(null)} className="text-neutral-500 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Voice Recording Active Banner */}
      {isRecordingVoice && (
        <div className="p-3 bg-rose-950/80 border-t border-rose-800/80 flex items-center justify-between text-xs animate-pulse">
          <div className="flex items-center gap-2 text-rose-300 font-bold">
            <Mic className="w-4 h-4 text-rose-500" />
            <span>Recording voice note: {voiceDuration}s</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => { setIsRecordingVoice(false); setVoiceDuration(0); }}
              className="text-neutral-400 hover:text-white text-xs"
            >
              Cancel
            </button>
            <button
              onClick={handleSendVoiceNote}
              className="px-3 py-1 rounded-lg bg-rose-500 text-white font-bold text-xs"
            >
              Send Note
            </button>
          </div>
        </div>
      )}

      {/* Bottom Message Input Bar */}
      <div className="p-2.5 bg-neutral-900/95 border-t border-neutral-800 backdrop-blur-md">
        
        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          className="hidden"
          accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
        />

        <form onSubmit={handleSendText} className="flex items-center gap-2">
          
          {/* Attachment button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition-colors"
            title="Attach Image, Video or Document"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Emoji button */}
          <button
            type="button"
            onClick={() => setShowEmojiPicker((prev) => !prev)}
            className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition-colors"
          >
            <Smile className="w-4 h-4" />
          </button>

          {/* Text Input */}
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-4 py-2 text-xs rounded-full bg-neutral-950 border border-neutral-800 text-white placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
          />

          {/* Send or Voice Record trigger */}
          {inputMessage.trim() ? (
            <button
              type="submit"
              className="p-2 rounded-full bg-rose-500 hover:bg-rose-600 text-white transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setIsRecordingVoice(true)}
              className="p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-rose-400 transition-colors"
              title="Record Voice Message"
            >
              <Mic className="w-4 h-4" />
            </button>
          )}

        </form>

        {/* Emoji Bar Picker */}
        {showEmojiPicker && (
          <div className="flex items-center justify-around py-2 border-t border-neutral-800 mt-2 text-xl">
            {['❤️', '🔥', '😂', '👏', '✨', '👍', '😍', '🙌', '💯'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => setInputMessage((prev) => prev + emoji)}
                className="hover:scale-125 transition-transform"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

      </div>

    </div>
  );
};
