import React, { useState, useRef } from 'react';
import { 
  X, 
  Film, 
  Image as ImageIcon, 
  Sparkles, 
  Scissors, 
  Music, 
  Hash, 
  IndianRupee, 
  ShoppingBag, 
  Clock, 
  Shield, 
  Check, 
  Upload, 
  Camera
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { uploadMediaFile } from '../../services/api';

export const CreateModal: React.FC = () => {
  const { 
    createModalType, 
    setCreateModalType, 
    addReel, 
    addPost, 
    addStory, 
    currentUser 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'reel' | 'post' | 'story' | 'product'>(
    createModalType || 'reel'
  );

  // File upload state
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  // Reel / Post details
  const [caption, setCaption] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [audioTitle, setAudioTitle] = useState('Original Audio - ' + currentUser.username);
  const [category, setCategory] = useState('Creative');

  // Video trimming controls
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(15); // seconds
  const [filterStyle, setFilterStyle] = useState('normal');

  // Exclusive post paywall price (if monetized)
  const [isExclusive, setIsExclusive] = useState(false);
  const [exclusivePrice, setExclusivePrice] = useState(199);

  // Story options
  const [isCloseFriendsOnly, setIsCloseFriendsOnly] = useState(false);

  // Digital product details
  const [productTitle, setProductTitle] = useState('');
  const [productPrice, setProductPrice] = useState(499);
  const [productType, setProductType] = useState<'course' | 'preset' | 'ebook'>('preset');
  const [productDesc, setProductDesc] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!createModalType) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setMediaFile(file);
      const { url } = await uploadMediaFile(file);
      setMediaPreview(url);
    }
  };

  const handlePublish = async () => {
    setUploading(true);
    // Simulate mobile upload optimization and video encoding
    await new Promise((r) => setTimeout(r, 800));

    const finalMediaUrl = mediaPreview || 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=600&auto=format&fit=crop&q=80';
    const parsedTags = hashtags
      .split(' ')
      .map((t) => t.replace('#', '').trim())
      .filter(Boolean);

    if (activeTab === 'reel') {
      addReel({
        videoUrl: finalMediaUrl,
        thumbnailUrl: finalMediaUrl,
        caption: caption || 'New Reel drop 🚀',
        audioTrack: {
          title: audioTitle,
          artist: currentUser.name,
          isOriginal: true,
          durationSeconds: trimEnd - trimStart,
        },
        hashtags: parsedTags.length > 0 ? parsedTags : ['ConnectReel', 'CreatorsIndia'],
        isTrending: false,
        category,
      });
    } else if (activeTab === 'post') {
      addPost({
        mediaType: 'image',
        mediaUrls: [finalMediaUrl],
        caption: caption || 'Fresh update!',
        hashtags: parsedTags,
        isExclusive,
        exclusivePrice: isExclusive ? exclusivePrice : undefined,
        hasUnlocked: true,
      });
    } else if (activeTab === 'story') {
      addStory(finalMediaUrl, 'image', caption, isCloseFriendsOnly);
    }

    setUploading(false);
    setCreateModalType(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in overflow-y-auto">
      <div className="w-full max-w-lg bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        
        {/* Top Header */}
        <div className="px-5 py-4 flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-rose-500" />
            <span className="text-sm font-bold text-white">Create & Publish Studio</span>
          </div>
          <button
            onClick={() => setCreateModalType(null)}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="grid grid-cols-4 p-2 bg-neutral-950/60 border-b border-neutral-800 text-xs font-semibold">
          {[
            { id: 'reel', label: 'Reel (9:16)', icon: <Film className="w-3.5 h-3.5" /> },
            { id: 'post', label: 'Post', icon: <ImageIcon className="w-3.5 h-3.5" /> },
            { id: 'story', label: '24h Story', icon: <Clock className="w-3.5 h-3.5" /> },
            { id: 'product', label: 'Sell Digital', icon: <ShoppingBag className="w-3.5 h-3.5" /> },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`py-2 px-1 rounded-xl flex items-center justify-center gap-1.5 transition-colors ${
                activeTab === t.id
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.icon}
              <span className="truncate">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 no-scrollbar">
          
          {/* Media Picker / Dropzone */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="relative aspect-video sm:aspect-[16/10] rounded-2xl border-2 border-dashed border-neutral-700 hover:border-rose-500/60 bg-neutral-950/60 flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-colors overflow-hidden group"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept={activeTab === 'reel' ? 'video/*' : 'image/*,video/*'}
              className="hidden"
            />

            {mediaPreview ? (
              <div className="relative w-full h-full flex items-center justify-center">
                {activeTab === 'reel' ? (
                  <video src={mediaPreview} controls className="max-h-full rounded-xl object-contain" />
                ) : (
                  <img src={mediaPreview} alt="Preview" className="max-h-full rounded-xl object-contain" />
                )}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <span className="text-xs font-semibold text-white bg-neutral-900/80 px-3 py-1.5 rounded-full">
                    Click to change file
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-neutral-800 flex items-center justify-center mx-auto text-rose-400">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Tap to upload from Gallery or Camera</p>
                  <p className="text-[11px] text-neutral-400">
                    {activeTab === 'reel'
                      ? 'Upload MP4/MOV high-res vertical clip (auto-compressed)'
                      : 'Upload photo or video'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Video Trimmer Scrubber (for Reel) */}
          {activeTab === 'reel' && (
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-neutral-200 flex items-center gap-1.5">
                  <Scissors className="w-3.5 h-3.5 text-rose-400" />
                  <span>Video Trimming</span>
                </span>
                <span className="text-[11px] text-rose-400 font-semibold tabular-nums">
                  Duration: {trimEnd - trimStart}s (max 60s)
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 space-y-1">
                  <span className="text-[10px] text-neutral-500">Start: {trimStart}s</span>
                  <input
                    type="range"
                    min="0"
                    max="30"
                    value={trimStart}
                    onChange={(e) => setTrimStart(Number(e.target.value))}
                    className="w-full accent-rose-500"
                  />
                </div>
                <div className="flex-1 space-y-1">
                  <span className="text-[10px] text-neutral-500">End: {trimEnd}s</span>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    value={trimEnd}
                    onChange={(e) => setTrimEnd(Number(e.target.value))}
                    className="w-full accent-rose-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Caption & Hashtags */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-300">Caption</label>
            <textarea
              rows={2}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Write a catchy caption that hooks the viewer..."
              className="w-full p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-rose-500 resize-none"
            />
          </div>

          {/* Hashtags Input */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
              <Hash className="w-3.5 h-3.5 text-rose-400" />
              <span>Hashtags</span>
            </label>
            <input
              type="text"
              value={hashtags}
              onChange={(e) => setHashtags(e.target.value)}
              placeholder="#StreetDance #MumbaiCreators #ConnectReel"
              className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {/* Reel Audio Selection */}
          {activeTab === 'reel' && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                <Music className="w-3.5 h-3.5 text-rose-400" />
                <span>Audio Track</span>
              </label>
              <input
                type="text"
                value={audioTitle}
                onChange={(e) => setAudioTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:outline-none focus:border-rose-500"
              />
            </div>
          )}

          {/* Post Monetization / Paywall Toggle */}
          {activeTab === 'post' && (
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Exclusive Creator Content</span>
                  </span>
                  <p className="text-[10px] text-neutral-400">Lock behind one-time fan unlock fee</p>
                </div>
                <input
                  type="checkbox"
                  checked={isExclusive}
                  onChange={(e) => setIsExclusive(e.target.checked)}
                  className="w-4 h-4 accent-amber-500 cursor-pointer"
                />
              </div>

              {isExclusive && (
                <div className="flex items-center gap-2 pt-2 border-t border-neutral-800">
                  <span className="text-xs text-neutral-300">Unlock Price:</span>
                  <div className="flex items-center gap-1 bg-neutral-900 px-3 py-1.5 rounded-xl border border-neutral-700">
                    <IndianRupee className="w-3.5 h-3.5 text-amber-400" />
                    <input
                      type="number"
                      value={exclusivePrice}
                      onChange={(e) => setExclusivePrice(Number(e.target.value))}
                      className="w-16 bg-transparent text-xs text-white focus:outline-none font-bold"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Story Close Friends Option */}
          {activeTab === 'story' && (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-950 border border-neutral-800">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-xs font-bold text-white">Close Friends Only</span>
                  <p className="text-[10px] text-neutral-400">Share with selected private circle</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={isCloseFriendsOnly}
                onChange={(e) => setIsCloseFriendsOnly(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>
          )}

        </div>

        {/* Bottom Publish Bar */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <button
            onClick={() => setCreateModalType(null)}
            className="px-4 py-2 text-xs font-bold text-neutral-400 hover:text-white"
          >
            Cancel
          </button>

          <button
            onClick={handlePublish}
            disabled={uploading}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 via-rose-500 to-amber-500 hover:opacity-90 text-white font-bold text-xs shadow-lg shadow-rose-500/25 active:scale-95 transition-transform flex items-center gap-2 disabled:opacity-50"
          >
            {uploading ? (
              <span>Optimizing & Publishing...</span>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Publish Now</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
