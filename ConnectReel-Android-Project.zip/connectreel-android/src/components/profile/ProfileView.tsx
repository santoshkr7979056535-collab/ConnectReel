import React, { useState } from 'react';
import { 
  Settings, 
  Wallet, 
  Grid, 
  Film, 
  Bookmark, 
  ShoppingBag, 
  TrendingUp, 
  BarChart2, 
  Users, 
  Heart, 
  Eye, 
  Share2, 
  Sparkles, 
  IndianRupee, 
  Check, 
  Plus, 
  Lock,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PrivacySettingsModal } from '../settings/PrivacySettingsModal';

export const ProfileView: React.FC = () => {
  const { 
    currentUser, 
    setCurrentUser, 
    posts, 
    reels, 
    products, 
    purchaseProduct, 
    setWalletModalOpen, 
    setCurrentTab,
    setCreateModalType 
  } = useApp();

  const [activeProfileTab, setActiveProfileTab] = useState<'grid' | 'reels' | 'store' | 'saved' | 'analytics'>('grid');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  
  // Edit Profile fields
  const [editName, setEditName] = useState(currentUser.name);
  const [editBio, setEditBio] = useState(currentUser.bio);
  const [editUsername, setEditUsername] = useState(currentUser.username);

  // Filter creator content
  const myPosts = posts.filter((p) => p.userId === currentUser.id);
  const myReels = reels.filter((r) => r.userId === currentUser.id);
  const savedPosts = posts.filter((p) => p.isSaved);
  const myProducts = products.filter((pr) => pr.creatorId === currentUser.id || currentUser.role === 'creator');

  // Highlights seed
  const highlights = [
    { title: 'Beats & Sound', cover: myPosts[0]?.mediaUrls[0] || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&auto=format&fit=crop&q=80' },
    { title: 'Choreo 2026', cover: myReels[0]?.thumbnailUrl || 'https://images.unsplash.com/photo-1547153760-18fc86324498?w=200&auto=format&fit=crop&q=80' },
    { title: 'Studio Setup', cover: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=200&auto=format&fit=crop&q=80' },
    { title: 'Travel Logs', cover: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=200&auto=format&fit=crop&q=80' },
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser((prev) => ({
      ...prev,
      name: editName,
      bio: editBio,
      username: editUsername,
    }));
    setEditProfileOpen(false);
  };

  return (
    <div className="w-full max-w-xl mx-auto pb-24 pt-2 px-3 sm:px-4 text-left">
      
      {/* Top Profile Header Bar */}
      <div className="flex items-center justify-between py-2 border-b border-neutral-800 mb-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-white tracking-tight">@{currentUser.username}</span>
          {currentUser.isVerified && (
            <span className="w-2 h-2 rounded-full bg-rose-500 ring-2 ring-neutral-900" />
          )}
        </div>

        <div className="flex items-center gap-2">
          {currentUser.role === 'creator' && (
            <button
              onClick={() => setWalletModalOpen(true)}
              className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
              title="Creator Wallet"
            >
              <Wallet className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setSettingsOpen(true)}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
            title="Privacy & Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Profile Info Row */}
      <div className="space-y-4 mb-4">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-20 h-20 rounded-full p-[2.5px] bg-gradient-to-tr from-violet-600 via-rose-500 to-amber-400 shadow-xl">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-full h-full rounded-full object-cover p-[2px] bg-neutral-950"
              />
            </div>
            {currentUser.badge && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.2 rounded-full bg-rose-500 text-white text-[9px] font-extrabold whitespace-nowrap shadow-md">
                PRO
              </span>
            )}
          </div>

          {/* Stats Bar */}
          <div className="flex-1 grid grid-cols-3 text-center">
            <div>
              <span className="text-sm font-extrabold text-white block tabular-nums">
                {myPosts.length + myReels.length}
              </span>
              <span className="text-[10px] text-neutral-400">Posts</span>
            </div>
            <div>
              <span className="text-sm font-extrabold text-white block tabular-nums">
                {(currentUser.followersCount / 1000).toFixed(1)}k
              </span>
              <span className="text-[10px] text-neutral-400">Followers</span>
            </div>
            <div>
              <span className="text-sm font-extrabold text-white block tabular-nums">
                {(currentUser.totalLikesCount / 1000).toFixed(0)}k
              </span>
              <span className="text-[10px] text-neutral-400">Likes</span>
            </div>
          </div>
        </div>

        {/* Bio Prose */}
        <div className="space-y-1">
          <h2 className="text-sm font-bold text-white">{currentUser.name}</h2>
          <p className="text-xs text-neutral-300 leading-relaxed whitespace-pre-line">
            {currentUser.bio}
          </p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {currentUser.interests.map((interest) => (
              <span
                key={interest}
                className="text-[10px] px-2.5 py-0.5 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-400 font-medium"
              >
                {interest}
              </span>
            ))}
          </div>
        </div>

        {/* Action Buttons: Edit Profile, Analytics, Share */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => setEditProfileOpen(true)}
            className="py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-200 text-xs font-semibold transition-colors"
          >
            Edit Profile
          </button>
          <button
            onClick={() => setActiveProfileTab('analytics')}
            className="py-2 rounded-xl bg-gradient-to-r from-violet-600/20 to-rose-600/20 border border-rose-500/30 text-rose-400 text-xs font-semibold hover:bg-rose-500/30 transition-colors flex items-center justify-center gap-1.5"
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Creator Analytics</span>
          </button>
        </div>
      </div>

      {/* Story Highlights Scroller */}
      <div className="py-2 mb-4 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-3">
          {highlights.map((hl) => (
            <div key={hl.title} className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group">
              <div className="w-14 h-14 rounded-full p-[2px] bg-neutral-800 group-hover:border-rose-500 transition-colors">
                <img
                  src={hl.cover}
                  alt={hl.title}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <span className="text-[10px] text-neutral-400 truncate max-w-[64px] text-center">
                {hl.title}
              </span>
            </div>
          ))}
          <div
            onClick={() => setCreateModalType('story')}
            className="flex flex-col items-center gap-1 shrink-0 cursor-pointer"
          >
            <div className="w-14 h-14 rounded-full border-2 border-dashed border-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white hover:border-white transition-colors">
              <Plus className="w-4 h-4" />
            </div>
            <span className="text-[10px] text-neutral-400">New</span>
          </div>
        </div>
      </div>

      {/* Profile Segmented Content Tabs */}
      <div className="grid grid-cols-5 border-t border-b border-neutral-800 text-xs py-1">
        {[
          { id: 'grid', label: 'Posts', icon: <Grid className="w-4 h-4" /> },
          { id: 'reels', label: 'Reels', icon: <Film className="w-4 h-4" /> },
          { id: 'store', label: 'Shop', icon: <ShoppingBag className="w-4 h-4" /> },
          { id: 'saved', label: 'Saved', icon: <Bookmark className="w-4 h-4" /> },
          { id: 'analytics', label: 'Insights', icon: <BarChart2 className="w-4 h-4" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveProfileTab(tab.id as any)}
            className={`py-2.5 flex flex-col items-center justify-center gap-1 transition-colors ${
              activeProfileTab === tab.id
                ? 'text-rose-500 font-bold border-b-2 border-rose-500'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            {tab.icon}
            <span className="text-[9px]">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: Posts Grid */}
      {activeProfileTab === 'grid' && (
        <div className="grid grid-cols-3 gap-1.5 pt-2">
          {myPosts.map((post) => (
            <div
              key={post.id}
              className="relative aspect-square bg-neutral-900 rounded-xl overflow-hidden cursor-pointer group"
            >
              <img
                src={post.mediaUrls[0]}
                alt={post.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-3 text-white text-xs font-bold transition-opacity">
                <span>❤️ {post.likesCount}</span>
                <span>💬 {post.commentsCount}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Reels 9:16 Vertical Grid */}
      {activeProfileTab === 'reels' && (
        <div className="grid grid-cols-3 gap-2 pt-2">
          {myReels.map((reel) => (
            <div
              key={reel.id}
              onClick={() => setCurrentTab('reels')}
              className="relative aspect-[9/16] bg-neutral-900 rounded-2xl overflow-hidden cursor-pointer group border border-neutral-800"
            >
              <img
                src={reel.thumbnailUrl}
                alt={reel.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between text-white text-[10px]">
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3 text-neutral-300" />
                  {(reel.viewsCount / 1000).toFixed(0)}k
                </span>
                <span>❤️ {(reel.likesCount / 1000).toFixed(1)}k</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Creator Digital Store / Courses */}
      {activeProfileTab === 'store' && (
        <div className="space-y-3 pt-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Creator Digital Products & Courses
            </span>
            <button
              onClick={() => setCreateModalType('product')}
              className="text-[11px] font-bold text-rose-400 hover:underline"
            >
              + List Product
            </button>
          </div>

          <div className="space-y-3">
            {myProducts.map((prod) => (
              <div
                key={prod.id}
                className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-3"
              >
                <img
                  src={prod.coverUrl}
                  alt={prod.title}
                  className="w-16 h-16 rounded-xl object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white truncate">{prod.title}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 uppercase font-bold">
                      {prod.type}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 line-clamp-1 mt-0.5">{prod.description}</p>
                  <div className="flex items-center gap-3 text-[10px] text-neutral-400 mt-1">
                    <span>⭐ {prod.rating} ({prod.reviewsCount})</span>
                    <span>·</span>
                    <span>{prod.salesCount} enrolled</span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-sm font-extrabold text-white block">
                    ₹{prod.priceINR.toLocaleString('en-IN')}
                  </span>
                  <button
                    onClick={() => purchaseProduct(prod)}
                    className="mt-1 px-3 py-1 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-90 text-white font-bold text-xs"
                  >
                    Buy
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Saved Posts */}
      {activeProfileTab === 'saved' && (
        <div className="grid grid-cols-3 gap-1.5 pt-2">
          {savedPosts.length === 0 ? (
            <div className="col-span-3 text-center py-10 text-xs text-neutral-400">
              No saved posts yet. Tap bookmark on any post or reel to save!
            </div>
          ) : (
            savedPosts.map((post) => (
              <div
                key={post.id}
                className="relative aspect-square bg-neutral-900 rounded-xl overflow-hidden cursor-pointer"
              >
                <img src={post.mediaUrls[0]} alt="Saved" className="w-full h-full object-cover" />
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 5: Creator Analytics & Growth Dashboard */}
      {activeProfileTab === 'analytics' && (
        <div className="space-y-4 pt-3 text-left">
          
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold block">Total 30-Day Views</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-xl font-extrabold text-white tabular-nums">482.4K</span>
                <span className="text-[10px] text-emerald-400 font-bold">+28.4%</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold block">Audience Engagement</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-xl font-extrabold text-white tabular-nums">11.8%</span>
                <span className="text-[10px] text-emerald-400 font-bold">+4.1%</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold block">Followers Gained</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-xl font-extrabold text-white tabular-nums">+1,840</span>
                <span className="text-[10px] text-emerald-400 font-bold">Mumbai & Delhi</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-semibold block">Estimated Revenue</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-xl font-extrabold text-emerald-400 tabular-nums">₹42,850</span>
                <span className="text-[10px] text-neutral-400">Available</span>
              </div>
            </div>
          </div>

          {/* Visual Growth Chart */}
          <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">Daily Reel Impressions (7 Days)</span>
              <span className="text-neutral-400 text-[10px]">Peak: 84k</span>
            </div>

            <div className="h-28 flex items-end justify-between gap-2 pt-4">
              {[
                { day: 'Mon', val: 45 },
                { day: 'Tue', val: 60 },
                { day: 'Wed', val: 52 },
                { day: 'Thu', val: 84 },
                { day: 'Fri', val: 78 },
                { day: 'Sat', val: 96 },
                { day: 'Sun', val: 92 },
              ].map((item) => (
                <div key={item.day} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    style={{ height: `${item.val}%` }}
                    className="w-full bg-gradient-to-t from-violet-600 to-rose-500 rounded-t-lg transition-all"
                  />
                  <span className="text-[9px] text-neutral-500">{item.day}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Edit Profile Modal */}
      {editProfileOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Edit Creator Profile</h3>
            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400">Full Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white mt-1"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400">Username</label>
                <input
                  type="text"
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white mt-1"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400">Bio</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white mt-1 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditProfileOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-rose-500 text-white text-xs font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {settingsOpen && (
        <PrivacySettingsModal onClose={() => setSettingsOpen(false)} />
      )}

    </div>
  );
};
