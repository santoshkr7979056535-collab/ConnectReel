import React, { useState, useRef, useEffect } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  Music, 
  Volume2, 
  VolumeX, 
  Plus, 
  Check, 
  MoreVertical, 
  Eye, 
  Sparkles, 
  Compass, 
  IndianRupee,
  ChevronUp,
  ChevronDown,
  Flag
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CommentDrawer } from '../feed/CommentDrawer';

export const ReelsViewer: React.FC = () => {
  const { 
    reels, 
    likeReel, 
    saveReel, 
    followUser, 
    currentUser, 
    sendTipToCreator,
    reportContent,
    setCreateModalType 
  } = useApp();

  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [tipOpen, setTipOpen] = useState(false);
  const [reelsTab, setReelsTab] = useState<'trending' | 'following'>('trending');

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const activeReel = reels[activeIndex];
  const isMe = activeReel?.userId === currentUser.id;

  const handleNext = () => {
    if (activeIndex < reels.length - 1) {
      setActiveIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveIndex((prev) => prev - 1);
    }
  };

  // Keyboard navigation up / down
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') handleNext();
      if (e.key === 'ArrowUp') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, reels.length]);

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const handleShare = () => {
    setShareSuccess(true);
    setTimeout(() => setShareSuccess(false), 2000);
  };

  if (!activeReel) return null;

  return (
    <div className="relative w-full h-[calc(100vh-3.5rem)] sm:h-[calc(100vh-3.5rem)] max-w-md mx-auto bg-black overflow-hidden select-none">
      
      {/* Top Overlay: Category Tabs & Sound Mute */}
      <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-between p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setReelsTab('trending')}
            className={`text-sm font-bold transition-all ${
              reelsTab === 'trending' ? 'text-white border-b-2 border-rose-500 pb-0.5' : 'text-neutral-400'
            }`}
          >
            Trending
          </button>
          <button
            onClick={() => setReelsTab('following')}
            className={`text-sm font-bold transition-all ${
              reelsTab === 'following' ? 'text-white border-b-2 border-rose-500 pb-0.5' : 'text-neutral-400'
            }`}
          >
            Following
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio toggle button */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-full bg-black/40 text-white backdrop-blur-md hover:bg-black/60 transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Quick Reel Camera Upload */}
          <button
            onClick={() => setCreateModalType('reel')}
            className="px-3 py-1.5 rounded-full bg-rose-500/90 text-white text-xs font-bold backdrop-blur-md flex items-center gap-1 hover:bg-rose-600 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create</span>
          </button>
        </div>
      </div>

      {/* Main 9:16 Media Viewport */}
      <div
        className="relative w-full h-full cursor-pointer flex items-center justify-center bg-neutral-950"
        onClick={togglePlayPause}
      >
        <video
          ref={videoRef}
          src={activeReel.videoUrl}
          poster={activeReel.thumbnailUrl}
          autoPlay
          loop
          playsInline
          muted={isMuted}
          className="w-full h-full object-cover"
        />

        {/* Video Scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30 pointer-events-none" />

        {/* Play/Pause indicator overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white/90">
              <span className="text-2xl">⏸</span>
            </div>
          </div>
        )}
      </div>

      {/* Vertical Navigation Chevrons */}
      <div className="absolute right-3 top-20 z-30 flex flex-col gap-1">
        {activeIndex > 0 && (
          <button
            onClick={handlePrev}
            className="p-1.5 rounded-full bg-black/40 backdrop-blur-md text-white/80 hover:text-white"
            title="Previous Reel"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}
        {activeIndex < reels.length - 1 && (
          <button
            onClick={handleNext}
            className="p-1.5 rounded-full bg-black/40 backdrop-blur-md text-white/80 hover:text-white"
            title="Next Reel"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Right Action Rail (Vertical Touch Zone) */}
      <div className="absolute right-3 bottom-24 z-30 flex flex-col items-center gap-4">
        
        {/* Creator Avatar with Follow (+) Button */}
        <div className="relative mb-2">
          <img
            src={activeReel.author.avatar}
            alt={activeReel.author.username}
            className="w-11 h-11 rounded-full object-cover ring-2 ring-white/90"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          {!isMe && !activeReel.author.isFollowing && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                followUser(activeReel.author.id);
              }}
              className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Like Button */}
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              likeReel(activeReel.id);
            }}
            className="p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:scale-110 active:scale-95 transition-transform"
          >
            <Heart
              className={`w-6 h-6 ${
                activeReel.isLiked ? 'fill-rose-500 text-rose-500' : 'text-white'
              }`}
            />
          </button>
          <span className="text-[11px] font-bold text-white tabular-nums drop-shadow-md">
            {(activeReel.likesCount / 1000).toFixed(1)}k
          </span>
        </div>

        {/* Comment Button */}
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setCommentsOpen(true);
            }}
            className="p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:scale-110 transition-transform"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
          <span className="text-[11px] font-bold text-white tabular-nums drop-shadow-md">
            {activeReel.commentsCount}
          </span>
        </div>

        {/* Bookmark / Save */}
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              saveReel(activeReel.id);
            }}
            className="p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:scale-110 transition-transform"
          >
            <Bookmark
              className={`w-6 h-6 ${
                activeReel.isSaved ? 'fill-amber-400 text-amber-400' : 'text-white'
              }`}
            />
          </button>
          <span className="text-[11px] font-bold text-white tabular-nums drop-shadow-md">
            {activeReel.savesCount}
          </span>
        </div>

        {/* Creator Fan Tip */}
        {!isMe && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setTipOpen((prev) => !prev);
            }}
            className="p-2.5 rounded-full bg-amber-500/30 border border-amber-400/50 backdrop-blur-md text-amber-300 hover:scale-110 transition-transform"
            title="Tip Creator with UPI"
          >
            <IndianRupee className="w-5 h-5" />
          </button>
        )}

        {/* Share Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleShare();
          }}
          className="p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:scale-110 transition-transform relative"
        >
          {shareSuccess ? <Check className="w-6 h-6 text-emerald-400" /> : <Share2 className="w-6 h-6" />}
        </button>

        {/* Report Content Flag */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setReportModalOpen(true);
          }}
          className="p-2 text-neutral-400 hover:text-rose-400 transition-colors"
          title="Report this video"
        >
          <Flag className="w-4 h-4" />
        </button>

        {/* Spinning Audio Track Disc */}
        <div className="mt-1 relative flex items-center justify-center">
          <div className="w-9 h-9 rounded-full bg-neutral-900 border-2 border-neutral-700 p-0.5 animate-spin duration-3000">
            <img
              src={activeReel.author.avatar}
              alt="Track"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          <Music className="w-3 h-3 text-rose-400 absolute -bottom-1 -left-1" />
        </div>

      </div>

      {/* Bottom Overlay: Creator info, caption, audio track & views */}
      <div className="absolute bottom-20 left-0 right-16 z-30 p-4 space-y-2 pointer-events-auto text-left">
        
        {/* Creator Tag & Verified */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-white hover:underline cursor-pointer">
            @{activeReel.author.username}
          </span>
          {activeReel.author.isVerified && (
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          )}
          <span className="text-[11px] text-neutral-300 flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm">
            <Eye className="w-3 h-3 text-neutral-400" />
            {(activeReel.viewsCount / 1000).toFixed(0)}k views
          </span>
        </div>

        {/* Caption */}
        <p className="text-xs text-neutral-100 line-clamp-2 leading-relaxed drop-shadow-md">
          {activeReel.caption}
        </p>

        {/* Hashtags */}
        <div className="flex flex-wrap gap-1.5">
          {activeReel.hashtags.map((h) => (
            <span key={h} className="text-xs font-semibold text-rose-300 drop-shadow">
              #{h}
            </span>
          ))}
        </div>

        {/* Audio Track Marquee */}
        <div className="flex items-center gap-2 pt-1 text-xs text-neutral-200">
          <Music className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span className="truncate max-w-[200px] font-medium">
            {activeReel.audioTrack.title} · {activeReel.audioTrack.artist}
          </span>
        </div>
      </div>

      {/* Tip Drawer for Reel */}
      {tipOpen && (
        <div 
          className="absolute bottom-24 inset-x-4 z-40 p-3 bg-neutral-900/95 border border-amber-500/40 rounded-2xl shadow-2xl backdrop-blur-xl flex items-center justify-between"
          onClick={(e) => e.stopPropagation()}
        >
          <span className="text-xs text-amber-300 font-bold">UPI Tip to @{activeReel.author.username}:</span>
          <div className="flex items-center gap-1.5">
            {[50, 100, 200, 500].map((amt) => (
              <button
                key={amt}
                onClick={() => {
                  sendTipToCreator(activeReel.author, amt);
                  setTipOpen(false);
                }}
                className="px-2.5 py-1 text-xs font-bold rounded-lg bg-neutral-800 text-white hover:bg-amber-500 hover:text-black transition-colors"
              >
                ₹{amt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Report Modal */}
      {reportModalOpen && (
        <div 
          className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white">Report Content</h3>
            <p className="text-xs text-neutral-400">
              Why are you reporting this reel from @{activeReel.author.username}?
            </p>
            <div className="space-y-2">
              {['Inappropriate or explicit content', 'Harassment or hate speech', 'Copyright or intellectual property', 'Spam or misleading information'].map((reason) => (
                <button
                  key={reason}
                  onClick={() => {
                    reportContent('reel', activeReel.id, reason);
                    setReportModalOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs font-medium bg-neutral-950 hover:bg-rose-500/20 text-neutral-200 rounded-xl border border-neutral-800 transition-colors"
                >
                  {reason}
                </button>
              ))}
            </div>
            <button
              onClick={() => setReportModalOpen(false)}
              className="w-full py-2 text-xs font-bold text-neutral-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Comments Drawer */}
      {commentsOpen && (
        <CommentDrawer
          itemId={activeReel.id}
          itemType="reel"
          title={`Comments on Reel`}
          onClose={() => setCommentsOpen(false)}
        />
      )}

    </div>
  );
};
