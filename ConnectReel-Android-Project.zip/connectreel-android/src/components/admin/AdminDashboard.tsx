import React, { useState } from 'react';
import { 
  ShieldCheck, 
  X, 
  Users, 
  Film, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  TrendingUp, 
  IndianRupee, 
  Search, 
  Megaphone, 
  Ban, 
  Check, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminDashboard: React.FC = () => {
  const { 
    adminPanelOpen, 
    setAdminPanelOpen, 
    allUsers, 
    banUser, 
    reports, 
    resolveReport, 
    withdrawals, 
    approveWithdrawal, 
    rejectWithdrawal, 
    transactions,
    reels 
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'withdrawals' | 'moderation' | 'users' | 'announcements'>('overview');
  const [userSearch, setUserSearch] = useState('');
  const [announcementText, setAnnouncementText] = useState('');
  const [announcementSent, setAnnouncementSent] = useState(false);

  if (!adminPanelOpen) return null;

  const pendingWithdrawals = withdrawals.filter((w) => w.status === 'pending');
  const pendingReports = reports.filter((r) => r.status === 'pending');

  const filteredUsers = allUsers.filter(
    (u) =>
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.username.toLowerCase().includes(userSearch.toLowerCase())
  );

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementText.trim()) return;
    setAnnouncementSent(true);
    setTimeout(() => {
      setAnnouncementSent(false);
      setAnnouncementText('');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in overflow-y-auto">
      <div className="w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden text-left my-auto">
        
        {/* Admin Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-500 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">ConnectReel Operations Console</h2>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-bold">
                  ADMIN ROOT
                </span>
              </div>
              <p className="text-xs text-neutral-400">Moderation, creator payouts & platform health</p>
            </div>
          </div>

          <button
            onClick={() => setAdminPanelOpen(false)}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Admin Segmented Nav Tabs */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-neutral-950/70 border-b border-neutral-800 overflow-x-auto no-scrollbar text-xs font-semibold">
          {[
            { id: 'overview', label: 'Platform Analytics' },
            { id: 'withdrawals', label: `Payout Requests (${pendingWithdrawals.length})` },
            { id: 'moderation', label: `Content Reports (${pendingReports.length})` },
            { id: 'users', label: `User Management (${allUsers.length})` },
            { id: 'announcements', label: 'Broadcast Message' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
                activeAdminTab === tab.id
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Admin Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 no-scrollbar text-xs">
          
          {/* TAB 1: OVERVIEW & ANALYTICS */}
          {activeAdminTab === 'overview' && (
            <div className="space-y-4">
              
              {/* Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
                  <span className="text-neutral-400 text-[10px] font-semibold block">Total Platform GMV</span>
                  <div className="text-xl font-extrabold text-emerald-400 mt-1">₹4,28,900</div>
                  <span className="text-[10px] text-neutral-500">100% UPI & Cards</span>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
                  <span className="text-neutral-400 text-[10px] font-semibold block">Platform Commission (5%)</span>
                  <div className="text-xl font-extrabold text-white mt-1">₹21,445</div>
                  <span className="text-[10px] text-emerald-400 font-bold">+18% this month</span>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
                  <span className="text-neutral-400 text-[10px] font-semibold block">Active Reels Published</span>
                  <div className="text-xl font-extrabold text-white mt-1">{reels.length}</div>
                  <span className="text-[10px] text-rose-400 font-bold">142k views avg</span>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
                  <span className="text-neutral-400 text-[10px] font-semibold block">Pending Payouts</span>
                  <div className="text-xl font-extrabold text-amber-400 mt-1">
                    ₹{pendingWithdrawals.reduce((a, b) => a + b.amountINR, 0).toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-amber-300">{pendingWithdrawals.length} awaiting review</span>
                </div>
              </div>

              {/* Transactions Stream */}
              <div className="p-4 rounded-3xl bg-neutral-950 border border-neutral-800 space-y-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider block">
                  Live System Transaction Ledger
                </span>
                <div className="space-y-2 max-h-56 overflow-y-auto no-scrollbar">
                  {transactions.map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-neutral-200">{t.description}</span>
                        <div className="text-[10px] text-neutral-400">
                          Ref: <span className="font-mono text-neutral-300">{t.referenceId}</span> · {t.createdAt}
                        </div>
                      </div>
                      <span className="font-mono font-bold text-emerald-400">
                        ₹{t.amountINR.toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: CREATOR WITHDRAWAL APPROVALS */}
          {activeAdminTab === 'withdrawals' && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                Pending Creator Payout Requests
              </span>

              {withdrawals.length === 0 ? (
                <div className="text-center py-10 text-neutral-400">No payout requests pending.</div>
              ) : (
                withdrawals.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={req.user.avatar}
                        alt={req.user.username}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{req.user.name}</span>
                          <span className="text-neutral-400">(@{req.user.username})</span>
                        </div>
                        <p className="text-neutral-300 mt-0.5">
                          Amount: <strong className="text-emerald-400 font-mono">₹{req.amountINR.toLocaleString('en-IN')}</strong> · UPI: <span className="font-mono text-rose-400">{req.upiId}</span>
                        </p>
                        <span className="text-[10px] text-neutral-500">Requested: {req.requestedAt}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {req.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => approveWithdrawal(req.id)}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve & Disburse</span>
                          </button>
                          <button
                            onClick={() => rejectWithdrawal(req.id)}
                            className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-rose-500/20 text-rose-400 font-bold text-xs"
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                          req.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {req.status.toUpperCase()}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 3: CONTENT MODERATION */}
          {activeAdminTab === 'moderation' && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                Flagged Content & Policy Reports
              </span>

              {reports.length === 0 ? (
                <div className="text-center py-10 text-neutral-400">Zero policy reports pending. All clear!</div>
              ) : (
                reports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 text-[10px] font-bold uppercase">
                          {rep.contentType}
                        </span>
                        <span className="text-neutral-400">Target ID: {rep.targetId}</span>
                      </div>
                      <p className="text-neutral-200 font-semibold">{rep.reason}</p>
                      <span className="text-[10px] text-neutral-500">Reported by: @{rep.reportedBy.username} · {rep.createdAt}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {rep.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => resolveReport(rep.id, true)}
                            className="px-3 py-1.5 rounded-xl bg-neutral-800 text-neutral-300 hover:text-white text-xs font-bold"
                          >
                            Dismiss
                          </button>
                          <button
                            onClick={() => resolveReport(rep.id, false)}
                            className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold"
                          >
                            Remove Item
                          </button>
                        </>
                      ) : (
                        <span className="text-emerald-400 font-bold">{rep.status.toUpperCase()}</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 4: USERS MANAGEMENT */}
          {activeAdminTab === 'users' && (
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search user accounts..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div className="space-y-2">
                {filteredUsers.map((u) => (
                  <div
                    key={u.id}
                    className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} alt={u.name} className="w-9 h-9 rounded-full object-cover" />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white">{u.name}</span>
                          <span className="text-neutral-400">@{u.username}</span>
                        </div>
                        <span className="text-[10px] text-neutral-500">
                          {u.followersCount.toLocaleString()} followers · Role: {u.role}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => banUser(u.id)}
                      className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500 hover:text-white text-xs font-bold flex items-center gap-1"
                    >
                      <Ban className="w-3 h-3" />
                      <span>Suspend</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: BROADCAST ANNOUNCEMENT */}
          {activeAdminTab === 'announcements' && (
            <form onSubmit={handleBroadcast} className="p-4 rounded-3xl bg-neutral-950 border border-neutral-800 space-y-4">
              <div className="flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="text-xs font-bold text-white">Broadcast Platform Announcement</h3>
                  <p className="text-[10px] text-neutral-400">Pushes a global notification to all creators and users</p>
                </div>
              </div>

              <textarea
                rows={3}
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                placeholder="e.g. New Monetization Policy: 0% platform fee on all video tips this festival week!"
                className="w-full p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-500 text-xs focus:outline-none focus:border-rose-500 resize-none"
              />

              {announcementSent ? (
                <div className="p-3 text-center text-xs text-emerald-400 font-bold bg-emerald-950/40 rounded-xl">
                  ✓ Broadcast announcement dispatched to all connected users!
                </div>
              ) : (
                <button
                  type="submit"
                  disabled={!announcementText.trim()}
                  className="px-5 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold disabled:opacity-40"
                >
                  Broadcast to Everyone
                </button>
              )}
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
