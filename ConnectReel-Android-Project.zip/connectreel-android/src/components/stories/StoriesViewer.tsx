import React, { useState, useEffect } from 'react';
import { X, Heart, Send, Eye, Shield, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Story } from '../../types';

interface StoriesViewerProps {
  initialStoryIndex?: number;
  onClose: () => void;
}

export const StoriesViewer: React.FC<StoriesViewerProps> = ({ initialStoryIndex = 0, onClose }) => {
  const { stories, currentUser, reactToStory, sendMessage, conversations } = useApp();
  const [currentIndex, setCurrentIndex] = useState(initialStoryIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showViewersSheet, setShowViewersSheet] = useState(false);
  const [reactionSent, setReactionSent] = useState<string | null>(null);

  const activeStory: Story | undefined = stories[currentIndex];
  const isMyStory = activeStory?.userId === currentUser.id;

  // Auto-progress bar 5 seconds per story
  useEffect(() => {
    if (isPaused || showViewersSheet) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((curr) => curr + 1);
            return 0;
          } else {
            clearInterval(interval);
            onClose();
            return 100;
          }
        }
        return prev + 2; // ~5 seconds total
      });
    }, 100);

    return () => clearInterval(interval);
  }, [currentIndex, isPaused, showViewersSheet, stories.length, onClose]);

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setProgress(0);
    }
  };

  const handleEmojiReact = (emoji: string) => {
    if (!activeStory) return;
    reactToStory(activeStory.id, emoji);
    setReactionSent(emoji);
    setTimeout(() => setReactionSent(null), 1500);

    // Also send reaction to creator's chat
    const targetConv = conversations.find(
      (c) => !c.isGroup && c.members.some((m) => m.id === activeStory.author.id)
    );
    if (targetConv) {
      sendMessage(targetConv.id, `Reacted ${emoji} to your story!`, 'text');
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeStory) return;

    const targetConv = conversations.find(
      (c) => !c.isGroup && c.members.some((m) => m.id === activeStory.author.id)
    );
    if (targetConv) {
      sendMessage(targetConv.id, `Replied to story: "${replyText.trim()}"`, 'text');
    }
    setReplyText('');
    setReactionSent('Sent!');
    setTimeout(() => setReactionSent(null), 1500);
  };

  if (!activeStory) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center select-none overflow-hidden">
      
      {/* Media Viewport */}
      <div className="relative w-full max-w-md h-full max-h-[92vh] sm:rounded-3xl overflow-hidden bg-neutral-900 flex flex-col justify-between shadow-2xl">
        
        {/* Background Image / Video */}
        <div 
          className="absolute inset-0 z-0 bg-neutral-950 cursor-pointer"
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {activeStory.mediaType === 'video' ? (
            <video
              src={activeStory.mediaUrl}
              autoPlay
              muted
              playsInline
              loop
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={activeStory.mediaUrl}
              alt="Story"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          )}
          {/* Subtle gradient scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/60 pointer-events-none" />
        </div>

        {/* Top Controls: Segmented Progress Bar & Author */}
        <div className="relative z-10 p-3 pt-4 space-y-2">
          
          {/* Progress Bars */}
          <div className="flex items-center gap-1.5 w-full">
            {stories.map((story, i) => (
              <div key={story.id} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
                  style={{
                    width:
                      i < currentIndex ? '100%' : i === currentIndex ? `${progress}%` : '0%',
                  }}
                />
              </div>
            ))}
          </div>

          {/* Author Details & Close */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={activeStory.author.avatar}
                alt={activeStory.author.username}
                className={`w-9 h-9 rounded-full object-cover ring-2 ${
                  activeStory.isCloseFriendsOnly ? 'ring-emerald-400' : 'ring-rose-500'
                }`}
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-white leading-none">
                    {activeStory.author.username}
                  </span>
                  {activeStory.isCloseFriendsOnly && (
                    <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-0.5">
                      <Shield className="w-3 h-3 inline" /> Close Friends
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-neutral-300">{activeStory.createdAt}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/40 hover:bg-black/70 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Middle Tap Areas for navigating left/right */}
        <div className="relative z-10 flex-1 grid grid-cols-2">
          <div onClick={handlePrev} className="h-full cursor-pointer" />
          <div onClick={handleNext} className="h-full cursor-pointer" />
        </div>

        {/* Reaction alert badge */}
        {reactionSent && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 px-4 py-2 rounded-2xl bg-black/70 backdrop-blur-md text-white text-lg font-bold animate-bounce">
            {reactionSent}
          </div>
        )}

        {/* Story Caption if present */}
        {activeStory.caption && (
          <div className="relative z-10 px-4 py-2 text-center">
            <p className="text-white text-sm font-medium drop-shadow-md bg-black/40 backdrop-blur-sm rounded-xl py-1.5 px-3 inline-block">
              {activeStory.caption}
            </p>
          </div>
        )}

        {/* Bottom Bar: Creator Viewer List OR Fan Reply/Emoji Bar */}
        <div className="relative z-10 p-3 pb-6">
          {isMyStory ? (
            <button
              onClick={() => setShowViewersSheet(true)}
              className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-neutral-900/80 backdrop-blur-md border border-neutral-700 text-white text-xs font-semibold hover:bg-neutral-800 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-rose-400" />
                <span>{activeStory.viewers.length} Viewers</span>
              </div>
              <span className="text-rose-400">View analytics →</span>
            </button>
          ) : (
            <div className="space-y-2">
              
              {/* Quick Emojis */}
              <div className="flex items-center justify-around px-2 py-1 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
                {['🔥', '❤️', '👏', '😂', '😮', '😍'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleEmojiReact(emoji)}
                    className="text-xl hover:scale-125 active:scale-95 transition-transform p-1"
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Text Reply Input */}
              <form onSubmit={handleSendReply} className="flex items-center gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={`Reply to ${activeStory.author.username}...`}
                  className="flex-1 px-4 py-2.5 rounded-full bg-neutral-900/90 backdrop-blur-md border border-neutral-700 text-xs text-white placeholder:text-neutral-400 focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="p-2.5 rounded-full bg-rose-500 text-white disabled:opacity-40 hover:bg-rose-600 transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

            </div>
          )}
        </div>

        {/* Viewers Sheet (for creator) */}
        {showViewersSheet && (
          <div className="absolute inset-x-0 bottom-0 z-30 bg-neutral-950/95 border-t border-neutral-800 rounded-t-3xl p-4 max-h-[60%] flex flex-col backdrop-blur-xl">
            <div className="w-10 h-1.5 bg-neutral-700 rounded-full mx-auto mb-3" />
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <span className="text-sm font-bold text-white">Story Viewers ({activeStory.viewers.length})</span>
              <button onClick={() => setShowViewersSheet(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-y-auto space-y-2.5 pt-3 no-scrollbar flex-1">
              {activeStory.viewers.length === 0 ? (
                <div className="text-center py-6 text-xs text-neutral-400">
                  No viewers yet. Your story was shared recently!
                </div>
              ) : (
                activeStory.viewers.map((viewer) => (
                  <div key={viewer.userId} className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img src={viewer.avatar} alt={viewer.username} className="w-8 h-8 rounded-full object-cover" />
                      <div>
                        <span className="text-xs font-bold text-white">@{viewer.username}</span>
                        <span className="text-[10px] text-neutral-400 block">{viewer.viewedAt}</span>
                      </div>
                    </div>
                    {activeStory.reactions.find((r) => r.userId === viewer.userId) && (
                      <span className="text-base">
                        {activeStory.reactions.find((r) => r.userId === viewer.userId)?.emoji}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
