import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Send, 
  Bookmark, 
  MoreHorizontal, 
  MapPin, 
  Lock, 
  Sparkles, 
  IndianRupee,
  Share2,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Post } from '../../types';
import { CommentDrawer } from './CommentDrawer';

interface PostCardProps {
  post: Post;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const { 
    currentUser, 
    likePost, 
    savePost, 
    followUser, 
    unlockExclusivePost, 
    sendTipToCreator,
    reportContent 
  } = useApp();

  const [commentsOpen, setCommentsOpen] = useState(false);
  const [showHeartOverlay, setShowHeartOverlay] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [tipOpen, setTipOpen] = useState(false);

  const isMe = post.userId === currentUser.id;

  const handleDoubleTap = () => {
    if (!post.isLiked) {
      likePost(post.id);
    }
    setShowHeartOverlay(true);
    setTimeout(() => setShowHeartOverlay(false), 900);
  };

  const handleShare = () => {
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <article className="w-full bg-neutral-900/60 border border-neutral-800/80 rounded-3xl overflow-hidden shadow-xl mb-5 transition-colors">
      
      {/* Header: Author Info */}
      <div className="p-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={post.author.avatar}
            alt={post.author.username}
            className="w-10 h-10 rounded-full object-cover ring-2 ring-rose-500/30"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-neutral-100 hover:text-rose-400 cursor-pointer">
                {post.author.name}
              </span>
              {post.author.isVerified && (
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              )}
              <span className="text-[11px] text-neutral-400">· @{post.author.username}</span>
            </div>
            {post.location && (
              <div className="flex items-center gap-1 text-[10px] text-neutral-400 mt-0.5">
                <MapPin className="w-2.5 h-2.5 text-rose-400" />
                <span className="truncate max-w-[180px]">{post.location}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Header: Follow Button & Menu */}
        <div className="flex items-center gap-1.5 relative">
          {!isMe && (
            <button
              onClick={() => followUser(post.author.id)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                post.author.isFollowing
                  ? 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                  : 'bg-rose-500/15 text-rose-400 border border-rose-500/30 hover:bg-rose-500 hover:text-white'
              }`}
            >
              {post.author.isFollowing ? 'Following' : '+ Follow'}
            </button>
          )}

          <button
            onClick={() => setMenuOpen((prev) => !prev)}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {/* Context Menu */}
          {menuOpen && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl p-1 z-30">
              <button
                onClick={() => {
                  reportContent('post', post.id, 'Inappropriate content');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-rose-400 hover:bg-neutral-800 rounded-lg"
              >
                Report Post
              </button>
              <button
                onClick={() => {
                  handleShare();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-neutral-300 hover:bg-neutral-800 rounded-lg"
              >
                Copy Link
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Media Box with double-tap heart */}
      <div 
        className="relative aspect-[4/3] bg-neutral-950 flex items-center justify-center overflow-hidden cursor-pointer"
        onDoubleClick={handleDoubleTap}
      >
        {post.mediaType === 'video' ? (
          <video
            src={post.mediaUrls[0]}
            controls
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <img
            src={post.mediaUrls[0]}
            alt={post.caption}
            className="w-full h-full object-cover select-none"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        )}

        {/* Double-tap heart animation */}
        {showHeartOverlay && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            <Heart className="w-20 h-20 fill-rose-500 text-rose-500 drop-shadow-2xl animate-ping" />
          </div>
        )}

        {/* Exclusive Content Blur / Paywall Overlay */}
        {post.isExclusive && !post.hasUnlocked && (
          <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-10">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mb-3">
              <Lock className="w-6 h-6 text-amber-400" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Creator Exclusive Content</h4>
            <p className="text-xs text-neutral-300 max-w-xs mb-4">
              Support @{post.author.username} to unlock high-res recipe blueprints & private masterclass presets.
            </p>
            <button
              onClick={() => unlockExclusivePost(post.id)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-transform flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              <span>Unlock for ₹{post.exclusivePrice}</span>
            </button>
          </div>
        )}
      </div>

      {/* Action Bar */}
      <div className="p-3.5 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            
            {/* Like Button */}
            <button
              onClick={() => likePost(post.id)}
              className="flex items-center gap-1.5 text-neutral-300 hover:text-rose-500 transition-colors"
            >
              <Heart
                className={`w-5 h-5 transition-transform active:scale-125 ${
                  post.isLiked ? 'fill-rose-500 text-rose-500' : ''
                }`}
              />
              <span className="text-xs font-semibold tabular-nums">{post.likesCount.toLocaleString()}</span>
            </button>

            {/* Comment Button */}
            <button
              onClick={() => setCommentsOpen(true)}
              className="flex items-center gap-1.5 text-neutral-300 hover:text-neutral-100 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-xs font-semibold tabular-nums">{post.commentsCount}</span>
            </button>

            {/* Share Button */}
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 text-neutral-300 hover:text-neutral-100 transition-colors"
              title="Share post"
            >
              {copiedLink ? <Check className="w-5 h-5 text-emerald-400" /> : <Share2 className="w-5 h-5" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Fan Tip Button */}
            {!isMe && (
              <button
                onClick={() => setTipOpen((prev) => !prev)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25 transition-colors"
                title="Send creator tip via UPI"
              >
                <IndianRupee className="w-3 h-3" />
                <span>Tip</span>
              </button>
            )}

            {/* Bookmark / Save */}
            <button
              onClick={() => savePost(post.id)}
              className={`p-1 text-neutral-300 hover:text-white transition-colors ${
                post.isSaved ? 'text-amber-400' : ''
              }`}
            >
              <Bookmark className={`w-5 h-5 ${post.isSaved ? 'fill-amber-400 text-amber-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Tip Selector Drawer */}
        {tipOpen && (
          <div className="p-2.5 bg-neutral-950/80 rounded-2xl border border-amber-500/30 flex items-center justify-between text-xs animate-fade-in">
            <span className="text-amber-300 font-semibold">Tip @{post.author.username}:</span>
            <div className="flex items-center gap-1.5">
              {[50, 100, 200, 500].map((amt) => (
                <button
                  key={amt}
                  onClick={() => {
                    sendTipToCreator(post.author, amt);
                    setTipOpen(false);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-amber-500 hover:text-neutral-950 text-neutral-200 font-bold transition-colors"
                >
                  ₹{amt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Caption & Hashtags */}
        <div className="text-left text-xs leading-relaxed space-y-1">
          <p className="text-neutral-200">
            <span className="font-bold mr-1.5 text-neutral-100">@{post.author.username}</span>
            {post.caption}
          </p>

          {post.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              {post.hashtags.map((h) => (
                <span key={h} className="text-rose-400 hover:underline cursor-pointer font-medium">
                  #{h}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Comments kicker & time */}
        <div className="flex items-center justify-between pt-1 text-[11px] text-neutral-500">
          <button
            onClick={() => setCommentsOpen(true)}
            className="hover:text-neutral-400 font-medium"
          >
            View all {post.commentsCount} comments
          </button>
          <span>{post.createdAt}</span>
        </div>
      </div>

      {/* Comments Drawer */}
      {commentsOpen && (
        <CommentDrawer
          itemId={post.id}
          itemType="post"
          onClose={() => setCommentsOpen(false)}
        />
      )}
    </article>
  );
};
