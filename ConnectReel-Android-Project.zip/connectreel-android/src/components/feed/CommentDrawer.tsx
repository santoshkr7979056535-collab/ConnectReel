import React, { useState } from 'react';
import { X, Send, Heart, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Comment } from '../../types';

interface CommentDrawerProps {
  itemId: string;
  itemType: 'post' | 'reel';
  title?: string;
  onClose: () => void;
}

export const CommentDrawer: React.FC<CommentDrawerProps> = ({ itemId, itemType, title, onClose }) => {
  const { currentUser, posts, reels } = useApp();
  
  // Sample seed comments
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 'c_1',
      userId: 'usr_1',
      author: {
        id: 'usr_1',
        username: 'rohit_moves',
        name: 'Rohit Verma',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
        role: 'creator',
        followersCount: 58200,
        followingCount: 412,
        totalLikesCount: 642000,
        isPrivate: false,
        interests: [],
        joinedDate: '',
        email: '',
        bio: 'Choreographer',
      },
      content: 'This edit is so clean! Loving the grade and audio timing 👏🔥',
      createdAt: '2h ago',
      likesCount: 24,
      isLiked: false,
    },
    {
      id: 'c_2',
      userId: 'usr_2',
      author: {
        id: 'usr_2',
        username: 'ananya_alpine',
        name: 'Ananya Sharma',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
        role: 'creator',
        followersCount: 112000,
        followingCount: 280,
        totalLikesCount: 1420000,
        isPrivate: false,
        interests: [],
        joinedDate: '',
        email: '',
        bio: 'Mountaineer',
      },
      content: 'The lighting here is magnificent. Keep inspiring us! ✨',
      createdAt: '45m ago',
      likesCount: 12,
      isLiked: true,
    },
  ]);

  const [inputVal, setInputVal] = useState('');

  const handleLikeComment = (commentId: string) => {
    setComments((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          const isLiked = !c.isLiked;
          return {
            ...c,
            isLiked,
            likesCount: isLiked ? c.likesCount + 1 : Math.max(0, c.likesCount - 1),
          };
        }
        return c;
      })
    );
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    const newComment: Comment = {
      id: 'c_' + Date.now(),
      userId: currentUser.id,
      author: currentUser,
      content: inputVal.trim(),
      createdAt: 'Just now',
      likesCount: 0,
      isLiked: false,
    };

    setComments((prev) => [newComment, ...prev]);
    setInputVal('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-lg bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl max-h-[80vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Grab bar */}
        <div className="w-10 h-1.5 bg-neutral-700 rounded-full mx-auto my-3 sm:hidden" />

        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-neutral-800">
          <div>
            <h3 className="text-sm font-bold text-neutral-100">Comments</h3>
            <span className="text-[11px] text-neutral-400">{comments.length} discussions</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {comments.map((comment) => (
            <div key={comment.id} className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <img
                  src={comment.author.avatar}
                  alt={comment.author.username}
                  className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="space-y-0.5 text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-neutral-200">
                      @{comment.author.username}
                    </span>
                    <span className="text-[10px] text-neutral-500">{comment.createdAt}</span>
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed">{comment.content}</p>
                  <button className="text-[10px] font-semibold text-neutral-500 hover:text-neutral-300 pt-0.5">
                    Reply
                  </button>
                </div>
              </div>

              <button
                onClick={() => handleLikeComment(comment.id)}
                className="flex flex-col items-center gap-0.5 text-neutral-500 hover:text-rose-500 transition-colors p-1"
              >
                <Heart
                  className={`w-3.5 h-3.5 ${
                    comment.isLiked ? 'fill-rose-500 text-rose-500' : ''
                  }`}
                />
                <span className="text-[10px] tabular-nums">{comment.likesCount}</span>
              </button>
            </div>
          ))}
        </div>

        {/* Quick Emoji Bar */}
        <div className="px-4 py-1.5 border-t border-neutral-800/80 flex items-center justify-between text-lg bg-neutral-950/40">
          {['❤️', '🙌', '🔥', '👏', '😍', '✨', '😂', '💯'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => setInputVal((prev) => prev + emoji)}
              className="hover:scale-125 transition-transform"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleAddComment} className="p-3 border-t border-neutral-800 bg-neutral-950 flex items-center gap-2">
          <img
            src={currentUser.avatar}
            alt={currentUser.username}
            className="w-7 h-7 rounded-full object-cover shrink-0"
          />
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder={`Add a comment as @${currentUser.username}...`}
            className="flex-1 px-3.5 py-2 text-xs rounded-full bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-rose-500"
          />
          <button
            type="submit"
            disabled={!inputVal.trim()}
            className="p-2 rounded-full bg-rose-500 text-white disabled:opacity-40 hover:bg-rose-600 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

      </div>
    </div>
  );
};
