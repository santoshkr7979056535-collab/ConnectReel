import React, { useState } from 'react';
import { Plus, Sparkles, TrendingUp, Users, Compass, RefreshCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PostCard } from './PostCard';
import { StoriesViewer } from '../stories/StoriesViewer';

export const HomeFeed: React.FC = () => {
  const { 
    posts, 
    stories, 
    currentUser, 
    allUsers, 
    followUser, 
    setCreateModalType,
    setCurrentTab 
  } = useApp();

  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [feedFilter, setFeedFilter] = useState<'for_you' | 'following'>('for_you');
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  };

  const suggestedUsers = allUsers.filter((u) => u.id !== currentUser.id && !u.isFollowing);

  return (
    <div className="w-full max-w-xl mx-auto pb-24 pt-2 px-3 sm:px-4">
      
      {/* Feed Filter Segmented Bar */}
      <div className="flex items-center justify-between py-2 mb-3">
        <div className="flex items-center gap-1 p-1 bg-neutral-900/80 rounded-2xl border border-neutral-800">
          <button
            onClick={() => setFeedFilter('for_you')}
            className={`px-4 py-1.5 text-xs font-bold rounded-xl transition-all ${
              feedFilter === 'for_you'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            For You
          </button>
          <button
            onClick={() => setFeedFilter('following')}
            className={`px-4 py-1.5 text-xs font-bold rounded-xl transition-all ${
              feedFilter === 'following'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Following
          </button>
        </div>

        <button
          onClick={handleRefresh}
          className={`p-2 rounded-xl text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900 transition-transform ${
            refreshing ? 'animate-spin text-rose-500' : ''
          }`}
          title="Refresh feed"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Stories Tray */}
      <div className="mb-5 overflow-x-auto no-scrollbar py-1">
        <div className="flex items-center gap-3">
          
          {/* Add to Your Story Button */}
          <div className="flex flex-col items-center gap-1.5 shrink-0">
            <div className="relative cursor-pointer" onClick={() => setCreateModalType('story')}>
              <div className="w-16 h-16 rounded-full p-[2px] bg-neutral-800">
                <img
                  src={currentUser.avatar}
                  alt="Your story"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-rose-500 border-2 border-neutral-950 flex items-center justify-center text-white">
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>
            <span className="text-[11px] font-medium text-neutral-300">Your Story</span>
          </div>

          {/* Followed Creators Stories */}
          {stories.map((story, idx) => {
            const isCloseFriend = story.isCloseFriendsOnly;
            return (
              <div
                key={story.id}
                onClick={() => setActiveStoryIndex(idx)}
                className="flex flex-col items-center gap-1.5 shrink-0 cursor-pointer group"
              >
                <div
                  className={`w-16 h-16 rounded-full p-[2.5px] transition-transform duration-200 group-hover:scale-105 ${
                    isCloseFriend
                      ? 'bg-gradient-to-tr from-emerald-500 via-teal-400 to-green-300'
                      : 'bg-gradient-to-tr from-rose-500 via-violet-500 to-amber-400'
                  }`}
                >
                  <div className="w-full h-full bg-neutral-950 rounded-full p-[2px]">
                    <img
                      src={story.author.avatar}
                      alt={story.author.username}
                      className="w-full h-full rounded-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                </div>
                <span className="text-[11px] font-medium text-neutral-300 max-w-[68px] truncate text-center">
                  {story.author.username}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Suggested Creators Strip (if any un-followed) */}
      {suggestedUsers.length > 0 && (
        <div className="mb-6 p-4 rounded-3xl bg-neutral-900/40 border border-neutral-800/80">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-300">
              <Sparkles className="w-3.5 h-3.5 text-rose-400" />
              <span>Suggested Creators for You</span>
            </div>
            <button
              onClick={() => setCurrentTab('communities')}
              className="text-[11px] font-semibold text-rose-400 hover:underline"
            >
              Explore all →
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {suggestedUsers.slice(0, 2).map((user) => (
              <div
                key={user.id}
                className="p-3 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex flex-col items-center text-center space-y-2"
              >
                <img
                  src={user.avatar}
                  alt={user.username}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-rose-500/20"
                />
                <div>
                  <h4 className="text-xs font-bold text-neutral-100 truncate w-32">{user.name}</h4>
                  <p className="text-[10px] text-neutral-400">@{user.username}</p>
                </div>
                <button
                  onClick={() => followUser(user.id)}
                  className="w-full py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold transition-colors"
                >
                  Follow
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Feed Posts */}
      <div className="space-y-4">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>

      {/* Stories Viewer Modal if active */}
      {activeStoryIndex !== null && (
        <StoriesViewer
          initialStoryIndex={activeStoryIndex}
          onClose={() => setActiveStoryIndex(null)}
        />
      )}

    </div>
  );
};
