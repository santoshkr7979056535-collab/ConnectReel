import React, { useState } from 'react';
import { 
  Bell, 
  Search, 
  Moon, 
  Sun, 
  Smartphone, 
  Monitor, 
  ShieldCheck, 
  Wallet, 
  Sparkles,
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Header: React.FC = () => {
  const { 
    currentUser, 
    theme, 
    toggleTheme, 
    isMobileFrame, 
    toggleMobileFrame,
    setSearchModalOpen,
    notifications,
    setWalletModalOpen,
    adminPanelOpen,
    setAdminPanelOpen,
    switchUserRole,
    markNotificationsAsRead
  } = useApp();

  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 w-full bg-neutral-950/85 dark:bg-neutral-950/85 bg-white/90 backdrop-blur-xl border-b border-neutral-800/60 dark:border-neutral-800/60 border-neutral-200 transition-colors">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        
        {/* Zone 1: Distinctive Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-violet-600 via-rose-500 to-amber-400 p-[2px] shadow-lg shadow-violet-500/20">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-rose-400 animate-pulse" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-neutral-100 via-rose-100 to-neutral-400 dark:from-white dark:via-rose-100 dark:to-neutral-400 text-neutral-900 bg-clip-text">
              Connect<span className="text-rose-500">Reel</span>
            </span>
            <span className="text-[10px] font-semibold tracking-wider uppercase text-rose-400/80 hidden sm:inline">
              LIVE
            </span>
          </div>
        </div>

        {/* Zone 2: Testing & Persona Quick-Switcher (Creator / Fan / Admin) */}
        <div className="relative">
          <button
            onClick={() => setRoleDropdownOpen((prev) => !prev)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-neutral-900/80 dark:bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 transition-colors"
            title="Switch demo persona to test creator, regular fan, or admin experience"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="capitalize">{currentUser.role} mode</span>
            <ChevronDown className="w-3 h-3 text-neutral-400" />
          </button>

          {roleDropdownOpen && (
            <div className="absolute top-full mt-1.5 left-1/2 -translate-x-1/2 w-48 bg-neutral-900/95 border border-neutral-800 rounded-xl shadow-2xl p-1.5 z-50 backdrop-blur-xl">
              <div className="px-2 py-1 text-[11px] font-semibold text-neutral-400 border-b border-neutral-800 mb-1">
                SWITCH TEST ROLE
              </div>
              <button
                onClick={() => { switchUserRole('creator'); setRoleDropdownOpen(false); }}
                className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                  currentUser.role === 'creator' ? 'bg-violet-600/20 text-violet-300 font-semibold' : 'text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <span>Creator (@karan_creates)</span>
                {currentUser.role === 'creator' && <UserCheck className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => { switchUserRole('user'); setRoleDropdownOpen(false); }}
                className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                  currentUser.role === 'user' ? 'bg-violet-600/20 text-violet-300 font-semibold' : 'text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <span>Fan User (@karan_fan)</span>
                {currentUser.role === 'user' && <UserCheck className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => { switchUserRole('admin'); setRoleDropdownOpen(false); }}
                className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between ${
                  currentUser.role === 'admin' ? 'bg-violet-600/20 text-violet-300 font-semibold' : 'text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <span>Safety Admin</span>
                {currentUser.role === 'admin' && <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />}
              </button>
            </div>
          )}
        </div>

        {/* Zone 3: Quick Action Affordances */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          
          {/* Creator Wallet trigger */}
          {currentUser.role === 'creator' && (
            <button
              onClick={() => setWalletModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 transition-colors"
              title="Creator Wallet & Earnings"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>₹{(currentUser.earnings?.balance || 0).toLocaleString('en-IN')}</span>
            </button>
          )}

          {/* Admin Dashboard trigger */}
          <button
            onClick={() => setAdminPanelOpen(!adminPanelOpen)}
            className={`p-2 rounded-lg text-xs transition-colors ${
              adminPanelOpen 
                ? 'bg-rose-500 text-white' 
                : 'text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900'
            }`}
            title="Open Admin Control Panel"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>

          {/* Search Trigger */}
          <button
            onClick={() => setSearchModalOpen(true)}
            className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900 transition-colors"
            title="Search creators, reels, hashtags"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              onClick={() => {
                setNotifDropdownOpen((prev) => !prev);
                markNotificationsAsRead();
              }}
              className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900 transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-neutral-950 animate-pulse" />
              )}
            </button>

            {/* Notification preview popup */}
            {notifDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-80 bg-neutral-900/95 border border-neutral-800 rounded-2xl shadow-2xl p-3 z-50 backdrop-blur-xl">
                <div className="flex items-center justify-between pb-2 border-b border-neutral-800 mb-2">
                  <span className="text-xs font-bold text-neutral-200">Notifications</span>
                  <span className="text-[10px] text-neutral-400">{notifications.length} updates</span>
                </div>
                <div className="max-h-72 overflow-y-auto space-y-2 no-scrollbar">
                  {notifications.slice(0, 6).map((n) => (
                    <div key={n.id} className="flex items-start gap-2.5 p-2 rounded-xl bg-neutral-800/40 hover:bg-neutral-800/80 transition-colors text-left text-xs">
                      <img 
                        src={n.actor.avatar} 
                        alt={n.actor.username} 
                        className="w-8 h-8 rounded-full object-cover shrink-0" 
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-neutral-200 leading-snug">
                          <span className="font-semibold text-rose-400">@{n.actor.username}</span>{' '}
                          <span className="text-neutral-300">{n.content}</span>
                        </p>
                        <span className="text-[10px] text-neutral-500 mt-0.5 block">{n.createdAt}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Responsive Device Frame Switcher (for desktop testing) */}
          <button
            onClick={toggleMobileFrame}
            className={`hidden md:flex p-2 rounded-lg text-xs transition-colors ${
              isMobileFrame ? 'bg-violet-600/30 text-violet-300 border border-violet-500/40' : 'text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900'
            }`}
            title={isMobileFrame ? 'Switch to Full Screen View' : 'Switch to Smartphone Device View'}
          >
            {isMobileFrame ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-900 transition-colors"
            title="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-neutral-700" />}
          </button>

        </div>
      </div>
    </header>
  );
};
