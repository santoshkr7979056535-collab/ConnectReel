import React, { useState, useMemo } from 'react';
import { Search, X, Users, Film, Hash, Compass, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SearchModal: React.FC = () => {
  const { 
    searchModalOpen, 
    setSearchModalOpen, 
    allUsers, 
    reels, 
    communities, 
    setCurrentTab,
    followUser 
  } = useApp();

  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'users' | 'reels' | 'hashtags' | 'communities'>('all');

  const filteredUsers = useMemo(() => {
    if (!query) return allUsers.slice(0, 4);
    return allUsers.filter(
      (u) =>
        u.username.toLowerCase().includes(query.toLowerCase()) ||
        u.name.toLowerCase().includes(query.toLowerCase()) ||
        u.bio.toLowerCase().includes(query.toLowerCase())
    );
  }, [allUsers, query]);

  const filteredReels = useMemo(() => {
    if (!query) return reels;
    return reels.filter(
      (r) =>
        r.caption.toLowerCase().includes(query.toLowerCase()) ||
        r.hashtags.some((h) => h.toLowerCase().includes(query.toLowerCase())) ||
        r.audioTrack.title.toLowerCase().includes(query.toLowerCase())
    );
  }, [reels, query]);

  const filteredCommunities = useMemo(() => {
    if (!query) return communities;
    return communities.filter(
      (c) =>
        c.name.toLowerCase().includes(query.toLowerCase()) ||
        c.description.toLowerCase().includes(query.toLowerCase())
    );
  }, [communities, query]);

  // Extract unique hashtags
  const hashtags = useMemo(() => {
    const set = new Set<string>();
    reels.forEach((r) => r.hashtags.forEach((h) => set.add(h)));
    return Array.from(set);
  }, [reels]);

  if (!searchModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl p-4 sm:p-6 shadow-2xl mt-4">
        
        {/* Header & Input */}
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-neutral-800">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search creators, reels, #hashtags, communities..."
              autoFocus
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 text-sm text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
            />
          </div>
          <button
            onClick={() => setSearchModalOpen(false)}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Segmented Controls (allowed button tabs per design system) */}
        <div className="flex items-center gap-1.5 py-3 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All' },
            { id: 'users', label: 'Creators' },
            { id: 'reels', label: 'Reels' },
            { id: 'hashtags', label: 'Hashtags' },
            { id: 'communities', label: 'Communities' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Results Container */}
        <div className="space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar pt-2">
          
          {/* Creators / Users */}
          {(activeCategory === 'all' || activeCategory === 'users') && filteredUsers.length > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
                <span>Creators ({filteredUsers.length})</span>
              </div>
              <div className="space-y-2">
                {filteredUsers.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 hover:border-neutral-700 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={user.avatar}
                        alt={user.username}
                        className="w-10 h-10 rounded-full object-cover shrink-0"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                      <div className="truncate">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-bold text-neutral-100 truncate">{user.name}</span>
                          {user.isVerified && (
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
                          )}
                        </div>
                        <p className="text-xs text-neutral-400 truncate">@{user.username} · {user.followersCount.toLocaleString()} followers</p>
                      </div>
                    </div>

                    <button
                      onClick={() => followUser(user.id)}
                      className={`px-3 py-1 rounded-xl text-xs font-semibold transition-colors ${
                        user.isFollowing
                          ? 'bg-neutral-800 text-neutral-300'
                          : 'bg-rose-500 text-white hover:bg-rose-600'
                      }`}
                    >
                      {user.isFollowing ? 'Following' : 'Follow'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reels */}
          {(activeCategory === 'all' || activeCategory === 'reels') && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
                <span>Trending Reels</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {filteredReels.map((reel) => (
                  <div
                    key={reel.id}
                    onClick={() => {
                      setCurrentTab('reels');
                      setSearchModalOpen(false);
                    }}
                    className="group relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer border border-neutral-800 bg-neutral-950"
                  >
                    <img
                      src={reel.thumbnailUrl}
                      alt={reel.caption}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-2 text-left">
                      <span className="text-[11px] font-bold text-white line-clamp-1">@{reel.author.username}</span>
                      <span className="text-[10px] text-neutral-300">{(reel.viewsCount / 1000).toFixed(0)}k views</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hashtags */}
          {(activeCategory === 'all' || activeCategory === 'hashtags') && (
            <div>
              <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
                Popular Hashtags
              </div>
              <div className="flex flex-wrap gap-2">
                {hashtags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      setQuery('#' + tag);
                      setActiveCategory('reels');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs font-medium text-neutral-300 hover:border-rose-500/50 hover:text-white transition-colors"
                  >
                    <Hash className="w-3.5 h-3.5 text-rose-400" />
                    <span>{tag}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Communities */}
          {(activeCategory === 'all' || activeCategory === 'communities') && (
            <div>
              <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
                Communities
              </div>
              <div className="space-y-2">
                {filteredCommunities.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => {
                      setCurrentTab('home'); // or community drawer
                      setSearchModalOpen(false);
                    }}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 hover:border-neutral-700 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={c.avatarUrl}
                        alt={c.name}
                        className="w-10 h-10 rounded-xl object-cover"
                      />
                      <div>
                        <span className="text-sm font-bold text-neutral-100">{c.name}</span>
                        <p className="text-xs text-neutral-400">{c.membersCount.toLocaleString()} members · {c.category}</p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-neutral-500" />
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
