import React from 'react';
import { Home, Film, Plus, MessageCircle, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NavTab } from '../../types';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, setCreateModalType, conversations, currentUser } = useApp();

  const totalUnreadMessages = conversations.reduce((acc, conv) => acc + (conv.unreadCount || 0), 0);

  const tabs: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home className="w-5 h-5" />,
    },
    {
      id: 'reels',
      label: 'Reels',
      icon: <Film className="w-5 h-5" />,
    },
    {
      id: 'create',
      label: 'Create',
      icon: <Plus className="w-6 h-6" />,
    },
    {
      id: 'chats',
      label: 'Chats',
      icon: (
        <div className="relative">
          <MessageCircle className="w-5 h-5" />
          {totalUnreadMessages > 0 && (
            <span className="absolute -top-1.5 -right-2 px-1.5 py-0.2 min-w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-neutral-950">
              {totalUnreadMessages}
            </span>
          )}
        </div>
      ),
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: currentUser.avatar ? (
        <img
          src={currentUser.avatar}
          alt={currentUser.username}
          className={`w-5 h-5 rounded-full object-cover ring-2 ${
            currentTab === 'profile' ? 'ring-rose-500' : 'ring-transparent'
          }`}
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      ) : (
        <User className="w-5 h-5" />
      ),
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/90 dark:bg-neutral-950/90 bg-white/90 backdrop-blur-xl border-t border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 shadow-2xl transition-colors">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-2">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;

          if (tab.id === 'create') {
            return (
              <div key={tab.id} className="flex items-center justify-center">
                <button
                  onClick={() => setCreateModalType('reel')}
                  className="min-h-[44px] min-w-[44px] w-11 h-11 rounded-2xl bg-gradient-to-tr from-violet-600 via-rose-500 to-amber-400 p-[1.5px] shadow-lg shadow-rose-500/25 active:scale-95 transition-transform flex items-center justify-center"
                  aria-label="Create new post, reel, story or product"
                >
                  <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center text-white hover:bg-neutral-900 transition-colors">
                    <Plus className="w-5 h-5 text-rose-400" />
                  </div>
                </button>
              </div>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors relative ${
                isActive
                  ? 'text-rose-500 dark:text-rose-400 font-semibold'
                  : 'text-neutral-400 hover:text-neutral-200 dark:text-neutral-400'
              }`}
            >
              <div className="flex items-center justify-center">
                {tab.icon}
              </div>
              <span className="text-[10px] tracking-tight mt-1 select-none">
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-1 h-1 rounded-full bg-rose-500 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
