import React, { useState } from 'react';
import { 
  X, 
  Shield, 
  Lock, 
  Eye, 
  MessageCircle, 
  Phone, 
  Download, 
  UserX, 
  Trash2, 
  Check, 
  AlertTriangle 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface PrivacySettingsModalProps {
  onClose: () => void;
}

export const PrivacySettingsModal: React.FC<PrivacySettingsModalProps> = ({ onClose }) => {
  const { 
    privacy, 
    updatePrivacySettings, 
    currentUser, 
    posts, 
    reels, 
    conversations,
    setOnboardingStep 
  } = useApp();

  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Download user data as real JSON export file
  const handleDownloadData = () => {
    const exportBundle = {
      exportTimestamp: new Date().toISOString(),
      account: currentUser,
      privacySettings: privacy,
      content: {
        postsCount: posts.filter((p) => p.userId === currentUser.id).length,
        reelsCount: reels.filter((r) => r.userId === currentUser.id).length,
        posts: posts.filter((p) => p.userId === currentUser.id),
      },
      messaging: {
        conversationsCount: conversations.length,
      }
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportBundle, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `connectreel_data_${currentUser.username}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleLogout = () => {
    setOnboardingStep(1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-lg bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden text-left">
        
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-rose-500" />
            <h3 className="text-sm font-bold text-white">Privacy, Safety & Account</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar text-xs">
          
          {/* Account Privacy */}
          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-white block">Private Account</span>
                <span className="text-[11px] text-neutral-400">
                  When private, only approved followers can see your posts and stories
                </span>
              </div>
              <input
                type="checkbox"
                checked={privacy.isPrivateAccount}
                onChange={(e) => updatePrivacySettings({ isPrivateAccount: e.target.checked })}
                className="w-4 h-4 accent-rose-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Messaging & Calling Permissions */}
          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h4 className="font-bold text-neutral-300 uppercase tracking-wider text-[11px]">
              Interactions & Communication
            </h4>

            <div>
              <label className="text-neutral-400 block mb-1">Who Can Message Me</label>
              <select
                value={privacy.whoCanMessageMe}
                onChange={(e) => updatePrivacySettings({ whoCanMessageMe: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white"
              >
                <option value="everyone">Everyone</option>
                <option value="following">People I Follow</option>
                <option value="nobody">Nobody</option>
              </select>
            </div>

            <div>
              <label className="text-neutral-400 block mb-1">Who Can Call Me</label>
              <select
                value={privacy.whoCanCallMe}
                onChange={(e) => updatePrivacySettings({ whoCanCallMe: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white"
              >
                <option value="everyone">Everyone</option>
                <option value="following">Followers Only</option>
                <option value="nobody">Nobody</option>
              </select>
            </div>
          </div>

          {/* Activity Status & Read Receipts */}
          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h4 className="font-bold text-neutral-300 uppercase tracking-wider text-[11px]">
              Status & Receipts
            </h4>

            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-white block">Online Status</span>
                <span className="text-[11px] text-neutral-400">Show when you are active on the platform</span>
              </div>
              <input
                type="checkbox"
                checked={privacy.onlineStatusVisibility}
                onChange={(e) => updatePrivacySettings({ onlineStatusVisibility: e.target.checked })}
                className="w-4 h-4 accent-rose-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between border-t border-neutral-850 pt-2">
              <div>
                <span className="font-bold text-white block">Read Receipts</span>
                <span className="text-[11px] text-neutral-400">Show blue checkmarks when messages are seen</span>
              </div>
              <input
                type="checkbox"
                checked={privacy.readReceipts}
                onChange={(e) => updatePrivacySettings({ readReceipts: e.target.checked })}
                className="w-4 h-4 accent-rose-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Download Data Section */}
          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-white">Download Your Data</span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Get an export of your creator profile, posts, reels metrics, and chat conversations.
            </p>
            <button
              onClick={handleDownloadData}
              className="mt-2 px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 text-white font-semibold text-xs flex items-center gap-1.5"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Data File Downloaded!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Export JSON Archive</span>
                </>
              )}
            </button>
          </div>

          {/* Danger Zone: Log Out / Delete */}
          <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-900/30 space-y-3">
            <h4 className="font-bold text-rose-400 uppercase tracking-wider text-[11px]">
              Account Actions
            </h4>

            <button
              onClick={handleLogout}
              className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 font-bold transition-colors text-xs text-center"
            >
              Log Out of ConnectReel
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
