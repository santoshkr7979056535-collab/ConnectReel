import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, 
  PhoneOff, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Volume2, 
  VolumeX, 
  Sparkles,
  User,
  ShieldAlert
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const CallingModal: React.FC = () => {
  const { 
    activeCall, 
    answerCall, 
    endCall, 
    toggleCallMute, 
    toggleCallCamera, 
    toggleCallSpeaker 
  } = useApp();

  const [hasPermissionError, setHasPermissionError] = useState(false);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);

  // Request actual camera/microphone stream if available in browser
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (activeCall.status === 'connected' && activeCall.type === 'video' && activeCall.isCameraOn) {
      navigator.mediaDevices?.getUserMedia({ video: true, audio: true })
        .then((s) => {
          stream = s;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = s;
          }
        })
        .catch((err) => {
          console.warn('Camera/Mic permission not granted or unavailable in environment, using simulated preview', err);
          setHasPermissionError(true);
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [activeCall.status, activeCall.type, activeCall.isCameraOn]);

  if (activeCall.status === 'idle' || !activeCall.partner) return null;

  const partner = activeCall.partner;
  const isVideo = activeCall.type === 'video';

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950 flex flex-col justify-between p-6 select-none overflow-hidden animate-fade-in">
      
      {/* Background Media / Video Streams */}
      {isVideo && activeCall.status === 'connected' ? (
        <div className="absolute inset-0 z-0 bg-neutral-900">
          
          {/* Remote Partner Video (Simulated HD stream) */}
          <img
            src={partner.avatar}
            alt={partner.name}
            className="w-full h-full object-cover filter brightness-75 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/60" />

          {/* Local User Self-Preview PiP window */}
          <div className="absolute top-6 right-6 w-28 sm:w-36 aspect-[9/16] rounded-2xl overflow-hidden border-2 border-white/20 shadow-2xl bg-neutral-950 z-20">
            {activeCall.isCameraOn ? (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover mirror"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-neutral-900 text-neutral-400 p-2 text-center text-[10px]">
                <VideoOff className="w-5 h-5 mb-1" />
                <span>Camera Off</span>
              </div>
            )}
          </div>

        </div>
      ) : (
        /* Voice Call Animated Audio Wave Backdrop */
        <div className="absolute inset-0 z-0 flex items-center justify-center bg-gradient-to-b from-neutral-900 via-neutral-950 to-black">
          <div className="relative flex items-center justify-center">
            {/* Glowing rings */}
            <div className="absolute w-72 h-72 rounded-full border border-rose-500/20 animate-ping duration-1000" />
            <div className="absolute w-56 h-56 rounded-full border border-violet-500/30 animate-pulse" />
          </div>
        </div>
      )}

      {/* Top Details Zone */}
      <div className="relative z-10 text-center pt-8 space-y-3">
        <div className="w-24 h-24 mx-auto rounded-full p-1 bg-gradient-to-tr from-violet-500 to-rose-500 shadow-2xl">
          <img
            src={partner.avatar}
            alt={partner.name}
            className="w-full h-full rounded-full object-cover"
          />
        </div>

        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">{partner.name}</h2>
          <p className="text-xs text-rose-400 font-semibold mt-0.5">@{partner.username}</p>
          <div className="text-xs text-neutral-300 mt-2 font-medium">
            {activeCall.status === 'calling' && 'Ringing...'}
            {activeCall.status === 'incoming' && 'Incoming Call...'}
            {activeCall.status === 'connected' && (
              <span className="font-mono tabular-nums text-sm bg-black/40 px-3 py-1 rounded-full border border-white/10">
                {formatTimer(activeCall.duration)}
              </span>
            )}
          </div>
        </div>

        {/* Audio Wave Bars when connected on Voice call */}
        {!isVideo && activeCall.status === 'connected' && (
          <div className="flex items-center justify-center gap-1.5 h-8 pt-4">
            {[40, 80, 50, 100, 70, 90, 60, 90, 40, 75, 95, 30].map((h, i) => (
              <span
                key={i}
                style={{ height: `${h}%` }}
                className="w-1.5 bg-gradient-to-t from-violet-500 to-rose-500 rounded-full animate-pulse"
              />
            ))}
          </div>
        )}
      </div>

      {/* Bottom Controls Zone */}
      <div className="relative z-10 pb-8 flex flex-col items-center gap-6 max-w-sm mx-auto w-full">
        
        {/* If incoming call: Answer or Reject */}
        {activeCall.status === 'incoming' ? (
          <div className="flex items-center justify-around w-full">
            <button
              onClick={endCall}
              className="flex flex-col items-center gap-2 text-xs text-neutral-300"
            >
              <div className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center text-white shadow-xl transition-transform active:scale-95">
                <PhoneOff className="w-7 h-7" />
              </div>
              <span>Decline</span>
            </button>

            <button
              onClick={answerCall}
              className="flex flex-col items-center gap-2 text-xs text-neutral-300"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 flex items-center justify-center text-white shadow-xl transition-transform active:scale-95 animate-bounce">
                <Phone className="w-7 h-7" />
              </div>
              <span>Accept</span>
            </button>
          </div>
        ) : (
          /* Active Call In-Call Controls */
          <div className="flex items-center justify-between w-full px-4">
            
            {/* Mute Mic */}
            <button
              onClick={toggleCallMute}
              className={`p-4 rounded-full transition-colors ${
                activeCall.isMuted
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-neutral-800 text-white hover:bg-neutral-700'
              }`}
              title={activeCall.isMuted ? 'Unmute' : 'Mute'}
            >
              {activeCall.isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>

            {/* Toggle Camera (if Video Call) */}
            {isVideo && (
              <button
                onClick={toggleCallCamera}
                className={`p-4 rounded-full transition-colors ${
                  !activeCall.isCameraOn
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    : 'bg-neutral-800 text-white hover:bg-neutral-700'
                }`}
                title="Toggle camera"
              >
                {activeCall.isCameraOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
              </button>
            )}

            {/* Speaker Toggle */}
            <button
              onClick={toggleCallSpeaker}
              className={`p-4 rounded-full transition-colors ${
                activeCall.isSpeaker
                  ? 'bg-neutral-800 text-white'
                  : 'bg-neutral-900 text-neutral-500'
              }`}
              title="Speaker mode"
            >
              {activeCall.isSpeaker ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </button>

            {/* End Call Button */}
            <button
              onClick={endCall}
              className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-xl transition-transform active:scale-95"
              title="End Call"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </div>
        )}
      </div>

    </div>
  );
};
