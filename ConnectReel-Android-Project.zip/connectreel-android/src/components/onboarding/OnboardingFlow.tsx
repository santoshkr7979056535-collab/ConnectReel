import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Phone, 
  Mail, 
  ShieldCheck, 
  User, 
  Camera, 
  Check, 
  Film, 
  Heart,
  Smartphone
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const OnboardingFlow: React.FC = () => {
  const { 
    onboardingStep, 
    setOnboardingStep, 
    currentUser, 
    setCurrentUser, 
    allUsers, 
    followUser 
  } = useApp();

  // Registration fields
  const [authMode, setAuthMode] = useState<'phone' | 'email'>('phone');
  const [phoneOrEmail, setPhoneOrEmail] = useState('+91 98765 43210');
  const [otpCode, setOtpCode] = useState(['5', '8', '2', '4', '1', '9']);
  const [otpSent, setOtpSent] = useState(false);

  // Profile setup
  const [chosenUsername, setChosenUsername] = useState('karan_creates');
  const [chosenName, setChosenName] = useState('Karan Kumar');
  const [chosenBio, setChosenBio] = useState('Filmmaker & Sound Designer 🎬');
  
  // Interests
  const allInterests = [
    'Dance & Beats', 'Himalayan Travel', 'Tech & Coding', 'Culinary & Coffee', 
    'Street Photography', 'Fitness & Calisthenics', 'Indie Gaming', 'Fashion & Style'
  ];
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'Dance & Beats', 'Himalayan Travel', 'Tech & Coding'
  ]);

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleFinishOnboarding = () => {
    setCurrentUser((prev) => ({
      ...prev,
      username: chosenUsername,
      name: chosenName,
      bio: chosenBio,
      interests: selectedInterests,
    }));
    setOnboardingStep(0); // 0 means completed
  };

  if (onboardingStep === 0) return null;

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950 flex items-center justify-center p-4 select-none overflow-y-auto">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-6 text-left my-auto">
        
        {/* Step Indicator */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-violet-600 to-rose-500 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-extrabold text-sm tracking-tight text-white">
              Connect<span className="text-rose-500">Reel</span>
            </span>
          </div>

          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5, 6, 7].map((s) => (
              <span
                key={s}
                className={`w-2 h-1.5 rounded-full transition-all ${
                  s === onboardingStep
                    ? 'w-5 bg-rose-500'
                    : s < onboardingStep
                    ? 'bg-neutral-600'
                    : 'bg-neutral-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* STEP 1: WELCOME SCREEN */}
        {onboardingStep === 1 && (
          <div className="space-y-4 text-center py-4">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-violet-600 via-rose-500 to-amber-400 p-[2px] mx-auto shadow-2xl shadow-rose-500/30">
              <div className="w-full h-full bg-neutral-950 rounded-[22px] flex items-center justify-center">
                <Sparkles className="w-9 h-9 text-rose-400" />
              </div>
            </div>

            <div className="space-y-1">
              <h1 className="text-2xl font-extrabold text-white">Welcome to ConnectReel</h1>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                Next-generation mobile platform combining messaging, short-form reels, stories, community hubs, calling, and creator monetization.
              </p>
            </div>

            <button
              onClick={() => setOnboardingStep(2)}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 via-rose-500 to-amber-500 text-white font-bold text-xs shadow-lg shadow-rose-500/25 active:scale-98 transition-transform flex items-center justify-center gap-2"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 2: REGISTER / LOGIN + OTP */}
        {onboardingStep === 2 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Register / Login</h2>
              <p className="text-xs text-neutral-400">Enter your phone number or email to receive a 6-digit verification OTP</p>
            </div>

            {!otpSent ? (
              <div className="space-y-3">
                <div className="flex gap-2 p-1 bg-neutral-950 rounded-xl border border-neutral-800 text-xs">
                  <button
                    type="button"
                    onClick={() => setAuthMode('phone')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-colors ${
                      authMode === 'phone' ? 'bg-rose-500 text-white' : 'text-neutral-400'
                    }`}
                  >
                    Mobile Phone
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthMode('email')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-colors ${
                      authMode === 'email' ? 'bg-rose-500 text-white' : 'text-neutral-400'
                    }`}
                  >
                    Email Address
                  </button>
                </div>

                <input
                  type="text"
                  value={phoneOrEmail}
                  onChange={(e) => setPhoneOrEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-semibold focus:outline-none focus:border-rose-500"
                />

                <button
                  type="button"
                  onClick={() => setOtpSent(true)}
                  className="w-full py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs transition-colors"
                >
                  Send 6-Digit OTP
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-center">
                  <span className="text-[11px] text-neutral-400 block">OTP sent to {phoneOrEmail}</span>
                  <span className="text-xs font-mono font-bold text-rose-400 mt-1 block">Test Code: 582419</span>
                </div>

                <div className="grid grid-cols-6 gap-2">
                  {otpCode.map((digit, idx) => (
                    <input
                      key={idx}
                      type="text"
                      maxLength={1}
                      value={digit}
                      readOnly
                      className="w-full aspect-square text-center font-bold text-sm bg-neutral-950 border border-neutral-700 rounded-xl text-white"
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setOnboardingStep(3)}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-bold text-xs shadow-lg transition-transform active:scale-98"
                >
                  Verify & Continue
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 3: CHOOSE USERNAME */}
        {onboardingStep === 3 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Choose Your Unique Handle</h2>
              <p className="text-xs text-neutral-400">Your unique creator tag across ConnectReel</p>
            </div>

            <div className="space-y-3">
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-rose-500 font-bold">@</span>
                <input
                  type="text"
                  value={chosenUsername}
                  onChange={(e) => setChosenUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono font-bold focus:outline-none focus:border-rose-500"
                />
              </div>
              <span className="text-[10px] text-emerald-400 block">✓ @{chosenUsername} is available!</span>
            </div>

            <button
              onClick={() => setOnboardingStep(4)}
              className="w-full py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
            >
              Continue
            </button>
          </div>
        )}

        {/* STEP 4: PROFILE PHOTO & DETAILS */}
        {onboardingStep === 4 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Setup Profile</h2>
              <p className="text-xs text-neutral-400">Add your display name, photo, and bio</p>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <img
                  src={currentUser.avatar}
                  alt="Avatar"
                  className="w-20 h-20 rounded-full object-cover ring-2 ring-rose-500"
                />
                <div className="absolute bottom-0 right-0 p-1.5 rounded-full bg-rose-500 text-white shadow-lg">
                  <Camera className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[11px] text-neutral-400">Full Name</label>
                <input
                  type="text"
                  value={chosenName}
                  onChange={(e) => setChosenName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs mt-1"
                />
              </div>

              <div>
                <label className="text-[11px] text-neutral-400">Bio</label>
                <input
                  type="text"
                  value={chosenBio}
                  onChange={(e) => setChosenBio(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs mt-1"
                />
              </div>
            </div>

            <button
              onClick={() => setOnboardingStep(5)}
              className="w-full py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
            >
              Save & Next
            </button>
          </div>
        )}

        {/* STEP 5: SELECT INTERESTS */}
        {onboardingStep === 5 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Select Your Interests</h2>
              <p className="text-xs text-neutral-400">We will personalize your Reels feed and communities</p>
            </div>

            <div className="flex flex-wrap gap-2">
              {allInterests.map((interest) => {
                const isSelected = selectedInterests.includes(interest);
                return (
                  <button
                    key={interest}
                    type="button"
                    onClick={() => toggleInterest(interest)}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-gradient-to-r from-violet-600 to-rose-500 text-white shadow-md'
                        : 'bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {interest} {isSelected && '✓'}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setOnboardingStep(6)}
              className="w-full py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
            >
              Continue ({selectedInterests.length} selected)
            </button>
          </div>
        )}

        {/* STEP 6: FOLLOW SUGGESTED CREATORS */}
        {onboardingStep === 6 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Follow Top Creators</h2>
              <p className="text-xs text-neutral-400">Kickstart your feed with premier creators across India</p>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto no-scrollbar">
              {allUsers.filter((u) => u.id !== currentUser.id).map((user) => (
                <div
                  key={user.id}
                  className="p-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                      <span className="text-xs font-bold text-white">{user.name}</span>
                      <span className="text-[10px] text-neutral-400 block">@{user.username} · {user.followersCount.toLocaleString()} fans</span>
                    </div>
                  </div>

                  <button
                    onClick={() => followUser(user.id)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold ${
                      user.isFollowing ? 'bg-neutral-800 text-neutral-400' : 'bg-rose-500 text-white'
                    }`}
                  >
                    {user.isFollowing ? 'Following' : 'Follow'}
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={() => setOnboardingStep(7)}
              className="w-full py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
            >
              Continue to Step 7
            </button>
          </div>
        )}

        {/* STEP 7: READY TO ENTER FEED */}
        {onboardingStep === 7 && (
          <div className="space-y-4 text-center py-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white">You're All Set!</h2>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                Welcome to ConnectReel, @{chosenUsername}. Explore Reels, connect with creators, and start broadcasting.
              </p>
            </div>

            <button
              onClick={handleFinishOnboarding}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 via-rose-500 to-amber-500 text-white font-bold text-xs shadow-xl active:scale-98 transition-transform"
            >
              Enter Main Feed 🚀
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
