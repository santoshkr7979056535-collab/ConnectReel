import React, { useState } from 'react';
import { 
  Users, 
  Lock, 
  Globe, 
  Plus, 
  MessageSquare, 
  FileText, 
  ShieldCheck, 
  Sparkles, 
  Share2, 
  ArrowLeft,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Community } from '../../types';

export const CommunitiesHub: React.FC = () => {
  const { 
    communities, 
    joinCommunity, 
    createCommunity, 
    currentUser, 
    reportContent 
  } = useApp();

  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [activeCommTab, setActiveCommTab] = useState<'posts' | 'chat' | 'rules'>('posts');

  // New community form fields
  const [newCommName, setNewCommName] = useState('');
  const [newCommDesc, setNewCommDesc] = useState('');
  const [newCommCategory, setNewCommCategory] = useState('Creative Arts');
  const [newCommIsPrivate, setNewCommIsPrivate] = useState(false);

  // Active community post feed seed
  const [communityPosts, setCommunityPosts] = useState([
    {
      id: 'cp_1',
      author: 'Karan Kumar',
      avatar: currentUser.avatar,
      title: 'Weekly Gear Swap & Lens Testing Meetup',
      content: 'Hey everyone, this Sunday we are meeting up in Bandra to test the new anamorphic lenses and drone filters. Drop a comment if you are joining!',
      likes: 38,
      comments: 14,
      time: '3 hours ago',
    },
    {
      id: 'cp_2',
      author: 'Rohit Verma',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
      title: 'Copyright Free Beat Pack Release for Community Members',
      content: 'Uploaded 5 new royalty-free drill and lo-fi stems exclusively for our community creators. Link pinned in discussion tab!',
      likes: 72,
      comments: 29,
      time: '1 day ago',
    },
  ]);

  const [communityChatMessages, setCommunityChatMessages] = useState([
    { id: '1', user: 'Priya', text: 'Hey guys, anyone tried the 60fps slow-mo export on Android?', time: '11:00 AM' },
    { id: '2', user: 'Rohit', text: 'Yes, ensure bitrate is set to 24Mbps for crisp playback!', time: '11:02 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommName.trim()) return;

    createCommunity({
      name: newCommName.trim(),
      slug: newCommName.toLowerCase().replace(/\s+/g, '-'),
      description: newCommDesc.trim(),
      bannerUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80',
      avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
      category: newCommCategory,
      isPrivate: newCommIsPrivate,
      rules: ['Respect fellow members', 'Keep discussions relevant to the community craft'],
    });

    setNewCommName('');
    setNewCommDesc('');
    setCreateModalOpen(false);
  };

  const handleSendCommunityChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setCommunityChatMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        user: currentUser.name,
        text: chatInput.trim(),
        time: 'Just now',
      },
    ]);
    setChatInput('');
  };

  return (
    <div className="w-full max-w-xl mx-auto pb-24 pt-2 px-3 sm:px-4">
      
      {/* If Inside a Community View */}
      {selectedCommunity ? (
        <div className="space-y-4 animate-fade-in text-left">
          
          {/* Back button */}
          <button
            onClick={() => setSelectedCommunity(null)}
            className="flex items-center gap-1.5 text-xs font-bold text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Communities</span>
          </button>

          {/* Banner & Header */}
          <div className="rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-900 shadow-xl">
            <div className="h-32 w-full relative bg-neutral-950">
              <img
                src={selectedCommunity.bannerUrl}
                alt="Banner"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent" />
            </div>

            <div className="p-4 -mt-10 relative space-y-3">
              <div className="flex items-end justify-between">
                <img
                  src={selectedCommunity.avatarUrl}
                  alt={selectedCommunity.name}
                  className="w-16 h-16 rounded-2xl object-cover ring-4 ring-neutral-900 shadow-lg"
                />

                <button
                  onClick={() => joinCommunity(selectedCommunity.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    selectedCommunity.isJoined
                      ? 'bg-neutral-800 text-neutral-300'
                      : 'bg-rose-500 hover:bg-rose-600 text-white'
                  }`}
                >
                  {selectedCommunity.isJoined ? 'Joined ✓' : '+ Join Community'}
                </button>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white">{selectedCommunity.name}</h2>
                  {selectedCommunity.isPrivate ? (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 font-semibold flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" /> Private
                    </span>
                  ) : (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 font-semibold flex items-center gap-1">
                      <Globe className="w-2.5 h-2.5" /> Public
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-400 mt-1">{selectedCommunity.description}</p>
                <div className="flex items-center gap-3 text-[11px] text-neutral-400 mt-2">
                  <span>{selectedCommunity.membersCount.toLocaleString()} members</span>
                  <span>·</span>
                  <span>{selectedCommunity.category}</span>
                  <span>·</span>
                  <span>{selectedCommunity.createdAt}</span>
                </div>
              </div>

              {/* Segmented Community Tabs */}
              <div className="flex items-center gap-1 border-t border-neutral-800 pt-3">
                {[
                  { id: 'posts', label: 'Posts & Updates' },
                  { id: 'chat', label: 'Community Chat' },
                  { id: 'rules', label: 'Rules & Guidelines' },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveCommTab(t.id as any)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
                      activeCommTab === t.id
                        ? 'bg-rose-500 text-white'
                        : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sub-view: Posts */}
          {activeCommTab === 'posts' && (
            <div className="space-y-3">
              {communityPosts.map((post) => (
                <div
                  key={post.id}
                  className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <img src={post.avatar} alt={post.author} className="w-7 h-7 rounded-full object-cover" />
                    <div>
                      <span className="text-xs font-bold text-white">{post.author}</span>
                      <span className="text-[10px] text-neutral-400 ml-2">{post.time}</span>
                    </div>
                  </div>
                  <h4 className="text-sm font-bold text-neutral-100">{post.title}</h4>
                  <p className="text-xs text-neutral-300 leading-relaxed">{post.content}</p>
                  <div className="flex items-center gap-4 pt-1 text-xs text-neutral-400">
                    <span>❤️ {post.likes} likes</span>
                    <span>💬 {post.comments} replies</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Sub-view: Chat */}
          {activeCommTab === 'chat' && (
            <div className="rounded-2xl border border-neutral-800 bg-neutral-900/80 p-3 flex flex-col h-80">
              <div className="flex-1 overflow-y-auto space-y-2 no-scrollbar p-1 text-xs">
                {communityChatMessages.map((msg) => (
                  <div key={msg.id} className="p-2 rounded-xl bg-neutral-950/70 border border-neutral-800/80">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-rose-400">{msg.user}</span>
                      <span className="text-[10px] text-neutral-500">{msg.time}</span>
                    </div>
                    <p className="text-neutral-200">{msg.text}</p>
                  </div>
                ))}
              </div>
              <form onSubmit={handleSendCommunityChat} className="flex items-center gap-2 pt-2 border-t border-neutral-800">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Message community..."
                  className="flex-1 px-3 py-1.5 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-xl bg-rose-500 text-white text-xs font-bold"
                >
                  Send
                </button>
              </form>
            </div>
          )}

          {/* Sub-view: Rules */}
          {activeCommTab === 'rules' && (
            <div className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Community Guidelines & Code of Conduct
              </h4>
              <ul className="space-y-2 text-xs text-neutral-300 list-disc list-inside">
                {selectedCommunity.rules.map((rule, idx) => (
                  <li key={idx}>{rule}</li>
                ))}
                <li>Zero tolerance for spam, hate speech, or harassment</li>
                <li>Give proper creative attribution to original filmmakers</li>
              </ul>
            </div>
          )}

        </div>
      ) : (
        /* All Communities Discovery Hub */
        <div className="space-y-4">
          
          {/* Header */}
          <div className="flex items-center justify-between py-2">
            <div>
              <h2 className="text-lg font-bold text-white">Creator Communities</h2>
              <p className="text-xs text-neutral-400">Join hubs of like-minded creators across India</p>
            </div>
            <button
              onClick={() => setCreateModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-rose-500 text-white hover:bg-rose-600 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Hub</span>
            </button>
          </div>

          {/* Community Cards */}
          <div className="space-y-3.5">
            {communities.map((comm) => (
              <div
                key={comm.id}
                onClick={() => setSelectedCommunity(comm)}
                className="rounded-3xl border border-neutral-800/80 bg-neutral-900/50 hover:bg-neutral-900 hover:border-neutral-700 transition-all cursor-pointer overflow-hidden shadow-lg"
              >
                <div className="h-28 relative bg-neutral-950">
                  <img
                    src={comm.bannerUrl}
                    alt={comm.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-black/20 to-transparent" />
                  
                  {/* Category Pill */}
                  <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-white border border-white/10">
                    {comm.category}
                  </span>
                </div>

                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-left">
                    <img
                      src={comm.avatarUrl}
                      alt={comm.name}
                      className="w-12 h-12 rounded-2xl object-cover ring-2 ring-neutral-800"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-sm font-bold text-white">{comm.name}</h3>
                        {comm.isPrivate ? (
                          <Lock className="w-3 h-3 text-neutral-400" />
                        ) : (
                          <Globe className="w-3 h-3 text-neutral-400" />
                        )}
                      </div>
                      <p className="text-xs text-neutral-400 line-clamp-1 mt-0.5">{comm.description}</p>
                      <span className="text-[10px] text-neutral-500 mt-1 block">
                        {comm.membersCount.toLocaleString()} members · {comm.postsCount} posts
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      joinCommunity(comm.id);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                      comm.isJoined
                        ? 'bg-neutral-800 text-neutral-300'
                        : 'bg-rose-500 hover:bg-rose-600 text-white'
                    }`}
                  >
                    {comm.isJoined ? 'Joined' : 'Join'}
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* Create Community Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-left">
            <h3 className="text-sm font-bold text-white">Create a New Creator Community</h3>
            <form onSubmit={handleCreateSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400">Community Name</label>
                <input
                  type="text"
                  value={newCommName}
                  onChange={(e) => setNewCommName(e.target.value)}
                  placeholder="e.g. Bangalore Coffee & Photography"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500 mt-1"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400">Description</label>
                <textarea
                  rows={2}
                  value={newCommDesc}
                  onChange={(e) => setNewCommDesc(e.target.value)}
                  placeholder="What is the focus of this community?"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500 mt-1 resize-none"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400">Category</label>
                <select
                  value={newCommCategory}
                  onChange={(e) => setNewCommCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500 mt-1"
                >
                  <option value="Creative Arts">Creative Arts</option>
                  <option value="Adventure">Adventure</option>
                  <option value="Technology">Technology</option>
                  <option value="Music & Audio">Music & Audio</option>
                  <option value="Fitness">Fitness</option>
                </select>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <span className="text-xs text-neutral-300">Private Community (Invite Only)</span>
                <input
                  type="checkbox"
                  checked={newCommIsPrivate}
                  onChange={(e) => setNewCommIsPrivate(e.target.checked)}
                  className="w-4 h-4 accent-rose-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newCommName.trim()}
                  className="px-4 py-1.5 rounded-xl bg-rose-500 text-white text-xs font-bold hover:bg-rose-600 disabled:opacity-40"
                >
                  Launch Hub
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
