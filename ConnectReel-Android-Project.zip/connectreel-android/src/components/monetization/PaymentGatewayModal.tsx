import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  CreditCard, 
  Smartphone, 
  Building2, 
  CheckCircle2, 
  Loader2, 
  Lock, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { processPayment } from '../../services/api';

export const PaymentGatewayModal: React.FC = () => {
  const { paymentModal, setPaymentModal, currentUser, setCurrentUser } = useApp();

  const [activeMethod, setActiveMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [selectedUpiApp, setSelectedUpiApp] = useState<'gpay' | 'phonepe' | 'paytm' | 'bhim' | 'custom'>('gpay');
  const [customVpa, setCustomVpa] = useState('');
  
  // Simulated Card Fields (Dummy test data, never stored raw)
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8921');
  const [cardHolder, setCardHolder] = useState('KARAN KUMAR');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('•••');

  // Net banking bank
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');

  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');

  if (!paymentModal.isOpen || !paymentModal.payload) return null;

  const { amountINR, purpose, targetName } = paymentModal.payload;

  const handlePayNow = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const res = await processPayment({
        ...paymentModal.payload!,
        paymentMethod: activeMethod,
        upiApp: selectedUpiApp as any,
        upiVpa: customVpa || 'karan@okaxis',
      });

      if (res.success) {
        setTransactionRef(res.transactionId);
        setIsProcessing(false);
        setIsSuccess(true);

        // Update current user earnings if creator was tipped/purchased
        setTimeout(() => {
          setIsSuccess(false);
          setPaymentModal({ isOpen: false, payload: null });
        }, 2200);
      }
    } catch (err) {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-md bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-left">
        
        {/* Gateway Header */}
        <div className="p-4 bg-gradient-to-r from-neutral-900 to-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">ConnectReel Secure Checkout</span>
              <span className="text-[10px] text-neutral-400">256-bit Encrypted · UPI & RBI Compliant</span>
            </div>
          </div>
          <button
            onClick={() => setPaymentModal({ isOpen: false, payload: null })}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Order Summary Strip */}
        <div className="p-4 bg-neutral-950/70 border-b border-neutral-800 flex items-center justify-between">
          <div className="truncate pr-2">
            <span className="text-xs font-semibold text-neutral-400 block truncate">{targetName}</span>
            <span className="text-[10px] text-emerald-400 font-medium">Instant Creator Delivery</span>
          </div>
          <div className="text-right shrink-0">
            <span className="text-base font-extrabold text-white">₹{amountINR.toLocaleString('en-IN')}</span>
            <span className="text-[9px] text-neutral-500 block">INR</span>
          </div>
        </div>

        {/* Success View */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-base font-bold text-white">Payment Successful!</h3>
            <p className="text-xs text-neutral-400">
              Transaction ID: <span className="font-mono text-emerald-400">{transactionRef}</span>
            </p>
            <p className="text-[11px] text-neutral-500">Unlocked and added to your creator library</p>
          </div>
        ) : (
          /* Payment Form */
          <form onSubmit={handlePayNow} className="p-4 space-y-4">
            
            {/* Method Tabs */}
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-neutral-950 rounded-2xl border border-neutral-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveMethod('upi')}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors ${
                  activeMethod === 'upi' ? 'bg-rose-500 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>UPI</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveMethod('card')}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors ${
                  activeMethod === 'card' ? 'bg-rose-500 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Cards</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveMethod('netbanking')}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors ${
                  activeMethod === 'netbanking' ? 'bg-rose-500 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Net Banking</span>
              </button>
            </div>

            {/* UPI Tab */}
            {activeMethod === 'upi' && (
              <div className="space-y-3">
                <span className="text-xs font-bold text-neutral-300 block">Popular UPI Apps</span>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'gpay', label: 'GPay' },
                    { id: 'phonepe', label: 'PhonePe' },
                    { id: 'paytm', label: 'Paytm' },
                    { id: 'bhim', label: 'BHIM' },
                  ].map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => setSelectedUpiApp(app.id as any)}
                      className={`p-2.5 rounded-2xl border text-xs font-bold text-center transition-all ${
                        selectedUpiApp === app.id
                          ? 'border-rose-500 bg-rose-500/10 text-white'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      {app.label}
                    </button>
                  ))}
                </div>

                <div className="pt-2">
                  <label className="text-[11px] text-neutral-400 block mb-1">Or enter UPI ID / VPA</label>
                  <input
                    type="text"
                    value={customVpa}
                    onChange={(e) => {
                      setCustomVpa(e.target.value);
                      setSelectedUpiApp('custom');
                    }}
                    placeholder="e.g. mobile@upi or username@okaxis"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white placeholder:text-neutral-600 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>
            )}

            {/* Card Tab */}
            {activeMethod === 'card' && (
              <div className="space-y-3">
                <div className="p-3 rounded-2xl bg-gradient-to-tr from-neutral-800 to-neutral-900 border border-neutral-700 text-white space-y-2">
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Credit / Debit Card</span>
                    <span className="text-rose-400 font-bold">VISA / RuPay</span>
                  </div>
                  <div className="font-mono text-sm tracking-wider">{cardNumber}</div>
                  <div className="flex justify-between text-[10px] text-neutral-400 pt-1">
                    <span>{cardHolder}</span>
                    <span>EXP: {cardExpiry}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-neutral-400">Expiry MM/YY</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400">CVV</label>
                    <input
                      type="password"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Net Banking Tab */}
            {activeMethod === 'netbanking' && (
              <div className="space-y-2">
                <label className="text-xs text-neutral-400">Select Bank</label>
                <select
                  value={selectedBank}
                  onChange={(e) => setSelectedBank(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="HDFC Bank">HDFC Bank</option>
                  <option value="State Bank of India">State Bank of India (SBI)</option>
                  <option value="ICICI Bank">ICICI Bank</option>
                  <option value="Axis Bank">Axis Bank</option>
                  <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                </select>
              </div>
            )}

            {/* Pay Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-rose-500 hover:opacity-95 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 active:scale-98 transition-transform flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Contacting Bank Gateway...</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Pay ₹{amountINR.toLocaleString('en-IN')} Securely</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <p className="text-[9px] text-neutral-500 text-center">
              Protected by ConnectReel Safety Protocol. Raw card numbers are never stored in databases.
            </p>
          </form>
        )}

      </div>
    </div>
  );
};
