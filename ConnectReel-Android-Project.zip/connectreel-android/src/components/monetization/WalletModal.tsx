import React, { useState } from 'react';
import { 
  X, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  IndianRupee, 
  Clock, 
  CheckCircle, 
  Sparkles, 
  Building2,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const WalletModal: React.FC = () => {
  const { 
    walletModalOpen, 
    setWalletModalOpen, 
    currentUser, 
    transactions, 
    withdrawals, 
    requestWithdrawal 
  } = useApp();

  const [payoutOpen, setPayoutOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState(5000);
  const [upiId, setUpiId] = useState('karan@okaxis');
  const [payoutSuccess, setPayoutSuccess] = useState(false);

  if (!walletModalOpen) return null;

  const earnings = currentUser.earnings || {
    balance: 42850,
    pendingPayout: 12500,
    totalEarned: 198400,
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (withdrawAmount <= 0 || withdrawAmount > earnings.balance || !upiId.trim()) return;

    requestWithdrawal(withdrawAmount, upiId.trim());
    setPayoutSuccess(true);
    setTimeout(() => {
      setPayoutSuccess(false);
      setPayoutOpen(false);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-lg bg-neutral-900 border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden text-left">
        
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Creator Earnings & Wallet</h3>
              <p className="text-[11px] text-neutral-400">Direct payouts via UPI and IMPS</p>
            </div>
          </div>
          <button
            onClick={() => setWalletModalOpen(false)}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          
          {/* Main Balance Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-tr from-neutral-950 via-neutral-900 to-neutral-800 border border-neutral-700/80 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-neutral-400 font-medium">Available for Withdrawal</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                Active
              </span>
            </div>

            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-extrabold text-white">
                  ₹{earnings.balance.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-neutral-400 font-bold">INR</span>
              </div>
              <div className="flex items-center gap-4 text-[11px] text-neutral-400 mt-2">
                <span>Pending Payout: <strong className="text-amber-400">₹{earnings.pendingPayout.toLocaleString('en-IN')}</strong></span>
                <span>·</span>
                <span>Lifetime: <strong className="text-emerald-400">₹{earnings.totalEarned.toLocaleString('en-IN')}</strong></span>
              </div>
            </div>

            <button
              onClick={() => setPayoutOpen(true)}
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 transition-all active:scale-98 flex items-center justify-center gap-1.5"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Request UPI Withdrawal</span>
            </button>
          </div>

          {/* Withdrawal Request Drawer */}
          {payoutOpen && (
            <form onSubmit={handleWithdrawSubmit} className="p-4 rounded-2xl bg-neutral-950 border border-emerald-500/40 space-y-3 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Enter Payout Details</span>
                <button type="button" onClick={() => setPayoutOpen(false)} className="text-neutral-400 text-xs">
                  Cancel
                </button>
              </div>

              {payoutSuccess ? (
                <div className="p-3 text-center text-xs text-emerald-400 font-bold bg-emerald-950/40 rounded-xl">
                  ✓ Withdrawal request submitted for Admin Approval!
                </div>
              ) : (
                <>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Amount to Withdraw (₹)</label>
                    <input
                      type="number"
                      max={earnings.balance}
                      min={100}
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-900 border border-neutral-800 text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Your Verified UPI ID (VPA)</label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="e.g. username@okaxis"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-900 border border-neutral-800 text-white font-mono"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2 rounded-xl bg-emerald-500 text-white text-xs font-bold hover:bg-emerald-600"
                  >
                    Confirm ₹{withdrawAmount.toLocaleString('en-IN')} Payout Request
                  </button>
                </>
              )}
            </form>
          )}

          {/* Pending Admin Approvals List */}
          {withdrawals.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block">
                Pending Approvals ({withdrawals.filter((w) => w.status === 'pending').length})
              </span>
              {withdrawals.map((w) => (
                <div key={w.id} className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center gap-1.5 font-bold text-white">
                      <span>₹{w.amountINR.toLocaleString('en-IN')}</span>
                      <span className="text-[10px] text-neutral-400">via {w.upiId}</span>
                    </div>
                    <span className="text-[10px] text-neutral-500">{w.requestedAt}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    w.status === 'approved'
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : w.status === 'rejected'
                      ? 'bg-rose-500/20 text-rose-400'
                      : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {w.status.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Transactions History */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block">
              Recent Transactions History
            </span>

            <div className="space-y-2">
              {transactions.map((tx) => {
                const isEarning = tx.type === 'earning' || tx.type === 'tip' || tx.type === 'subscription';
                return (
                  <div
                    key={tx.id}
                    className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl ${
                        isEarning ? 'bg-emerald-500/10 text-emerald-400' : 'bg-neutral-800 text-neutral-300'
                      }`}>
                        {isEarning ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="font-bold text-white line-clamp-1">{tx.description}</p>
                        <span className="text-[10px] text-neutral-500">{tx.createdAt} · {tx.paymentMethod}</span>
                      </div>
                    </div>

                    <span className={`font-mono font-bold ${
                      isEarning ? 'text-emerald-400' : 'text-neutral-300'
                    }`}>
                      {isEarning ? '+' : '-'}₹{tx.amountINR.toLocaleString('en-IN')}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
