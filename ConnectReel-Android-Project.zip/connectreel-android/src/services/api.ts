import {
  Post,
  Reel,
  Story,
  ChatMessage,
  Conversation,
  DigitalProduct,
  WalletTransaction,
  WithdrawalRequest,
  AppNotification,
  ContentReport,
  User
} from '../types';

// Storage keys for persistent state
const STORAGE_PREFIX = 'connectreel_';

export function getLocal<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(STORAGE_PREFIX + key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

export function setLocal<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('Error saving to storage', e);
  }
}

// Media upload helper: converts file or canvas to base64 Data URL and optimizes it
export async function uploadMediaFile(file: File): Promise<{ url: string; size: string; type: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const sizeKb = Math.round(file.size / 1024);
      const sizeStr = sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} MB` : `${sizeKb} KB`;
      resolve({
        url: result,
        size: sizeStr,
        type: file.type.startsWith('video/') ? 'video' : file.type.startsWith('audio/') ? 'audio' : 'image',
      });
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

// Real-time Event Bus for simulating cross-tab or server push events (messages, incoming calls, likes)
type EventCallback = (data: any) => void;

class EventBus {
  private listeners: Map<string, Set<EventCallback>> = new Map();

  subscribe(event: string, callback: EventCallback): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => {
      this.listeners.get(event)?.delete(callback);
    };
  }

  emit(event: string, data?: any): void {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.forEach((cb) => {
        try {
          cb(data);
        } catch (e) {
          console.error(`Error in event listener for ${event}:`, e);
        }
      });
    }
  }
}

export const appEvents = new EventBus();

// Payment processing simulator (UPI, Cards, NetBanking)
export interface PaymentIntentPayload {
  amountINR: number;
  purpose: 'tip' | 'subscription' | 'product' | 'exclusive_post';
  targetId: string; // creatorId or productId or postId
  targetName: string;
  paymentMethod: 'upi' | 'card' | 'netbanking';
  upiApp?: 'gpay' | 'phonepe' | 'paytm' | 'bhim' | 'custom_upi';
  upiVpa?: string;
  cardInfo?: {
    last4: string;
    holderName: string;
    expiry: string;
  };
  bankName?: string;
}

export async function processPayment(payload: PaymentIntentPayload): Promise<{ success: boolean; transactionId: string; message: string }> {
  // Simulate network roundtrip to payment gateway (Razorpay / Cashfree simulation)
  await new Promise((resolve) => setTimeout(resolve, 1400));
  
  const txId = 'PAY_' + Math.random().toString(36).substring(2, 9).toUpperCase();
  return {
    success: true,
    transactionId: txId,
    message: `Payment of ₹${payload.amountINR} processed successfully via ${payload.paymentMethod.toUpperCase()}`,
  };
}
