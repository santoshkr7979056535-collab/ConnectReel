import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Post,
  Reel,
  Story,
  ChatMessage,
  Conversation,
  Community,
  DigitalProduct,
  CallRecord,
  WalletTransaction,
  WithdrawalRequest,
  AppNotification,
  ContentReport,
  PrivacySettings,
  NavTab
} from '../types';
import {
  CURRENT_USER,
  ADMIN_USER,
  SAMPLE_USERS,
  INITIAL_REELS,
  INITIAL_POSTS,
  INITIAL_STORIES,
  INITIAL_CONVERSATIONS,
  INITIAL_CALLS,
  INITIAL_COMMUNITIES,
  INITIAL_PRODUCTS,
  INITIAL_TRANSACTIONS,
  INITIAL_WITHDRAWALS,
  INITIAL_NOTIFICATIONS,
  INITIAL_REPORTS,
  DEFAULT_PRIVACY_SETTINGS,
} from '../data/mockData';
import { getLocal, setLocal, appEvents, processPayment, PaymentIntentPayload } from '../services/api';

interface AppContextType {
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User>>;
  allUsers: User[];
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  posts: Post[];
  reels: Reel[];
  stories: Story[];
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActiveConversation: (c: Conversation | null) => void;
  calls: CallRecord[];
  activeCall: {
    status: 'idle' | 'calling' | 'incoming' | 'connected';
    type: 'voice' | 'video';
    partner: User | null;
    isMuted: boolean;
    isCameraOn: boolean;
    isSpeaker: boolean;
    duration: number;
  };
  communities: Community[];
  products: DigitalProduct[];
  transactions: WalletTransaction[];
  withdrawals: WithdrawalRequest[];
  notifications: AppNotification[];
  reports: ContentReport[];
  privacy: PrivacySettings;
  theme: 'dark' | 'light';
  isMobileFrame: boolean;
  onboardingStep: number; // 0 = completed, 1..7 = active onboarding
  createModalType: 'post' | 'reel' | 'story' | 'product' | null;
  setCreateModalType: (type: 'post' | 'reel' | 'story' | 'product' | null) => void;
  searchModalOpen: boolean;
  setSearchModalOpen: (open: boolean) => void;
  walletModalOpen: boolean;
  setWalletModalOpen: (open: boolean) => void;
  adminPanelOpen: boolean;
  setAdminPanelOpen: (open: boolean) => void;
  paymentModal: {
    isOpen: boolean;
    payload: PaymentIntentPayload | null;
  };
  setPaymentModal: React.Dispatch<React.SetStateAction<{ isOpen: boolean; payload: PaymentIntentPayload | null }>>;
  
  // Actions
  toggleTheme: () => void;
  toggleMobileFrame: () => void;
  setOnboardingStep: (step: number) => void;
  switchUserRole: (role: 'creator' | 'user' | 'admin') => void;
  likePost: (postId: string) => void;
  savePost: (postId: string) => void;
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'author' | 'userId' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount'>) => void;
  unlockExclusivePost: (postId: string) => Promise<boolean>;
  likeReel: (reelId: string) => void;
  saveReel: (reelId: string) => void;
  addReel: (reel: Omit<Reel, 'id' | 'createdAt' | 'author' | 'userId' | 'viewsCount' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount'>) => void;
  reportContent: (contentType: 'reel' | 'post' | 'user' | 'community', targetId: string, reason: string) => void;
  addStory: (mediaUrl: string, mediaType: 'image' | 'video', caption?: string, isCloseFriends?: boolean) => void;
  viewStory: (storyId: string) => void;
  reactToStory: (storyId: string, emoji: string) => void;
  followUser: (userId: string) => void;
  sendMessage: (convId: string, content: string, type?: ChatMessage['type'], mediaUrl?: string, replyTo?: any) => void;
  deleteMessage: (convId: string, messageId: string) => void;
  reactToMessage: (convId: string, messageId: string, emoji: string) => void;
  createGroup: (name: string, description: string, memberIds: string[]) => string;
  startCall: (partner: User, type: 'voice' | 'video') => void;
  answerCall: () => void;
  endCall: () => void;
  toggleCallMute: () => void;
  toggleCallCamera: () => void;
  toggleCallSpeaker: () => void;
  joinCommunity: (communityId: string) => void;
  createCommunity: (comm: Omit<Community, 'id' | 'createdAt' | 'membersCount' | 'postsCount' | 'isJoined' | 'moderators'>) => void;
  purchaseProduct: (product: DigitalProduct) => Promise<boolean>;
  sendTipToCreator: (creator: User, amountINR: number, note?: string) => Promise<boolean>;
  requestWithdrawal: (amountINR: number, upiId: string) => void;
  approveWithdrawal: (requestId: string) => void;
  rejectWithdrawal: (requestId: string) => void;
  resolveReport: (reportId: string, dismiss?: boolean) => void;
  banUser: (userId: string) => void;
  updatePrivacySettings: (settings: Partial<PrivacySettings>) => void;
  markNotificationsAsRead: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme & Layout
  const [theme, setTheme] = useState<'dark' | 'light'>(() => getLocal('theme', 'dark'));
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(() => getLocal('isMobileFrame', false));
  const [onboardingStep, setOnboardingStep] = useState<number>(() => getLocal('onboarding_completed', true) ? 0 : 1);

  // Active User & All users
  const [currentUser, setCurrentUser] = useState<User>(() => getLocal('current_user', CURRENT_USER));
  const [allUsers, setAllUsers] = useState<User[]>(() => getLocal('all_users', [CURRENT_USER, ...SAMPLE_USERS]));

  // Feed, Content & Navigation
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [posts, setPosts] = useState<Post[]>(() => getLocal('posts', INITIAL_POSTS));
  const [reels, setReels] = useState<Reel[]>(() => getLocal('reels', INITIAL_REELS));
  const [stories, setStories] = useState<Story[]>(() => getLocal('stories', INITIAL_STORIES));
  const [conversations, setConversations] = useState<Conversation[]>(() => getLocal('conversations', INITIAL_CONVERSATIONS));
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [calls, setCalls] = useState<CallRecord[]>(() => getLocal('calls', INITIAL_CALLS));
  const [communities, setCommunities] = useState<Community[]>(() => getLocal('communities', INITIAL_COMMUNITIES));
  const [products, setProducts] = useState<DigitalProduct[]>(() => getLocal('products', INITIAL_PRODUCTS));
  const [transactions, setTransactions] = useState<WalletTransaction[]>(() => getLocal('transactions', INITIAL_TRANSACTIONS));
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => getLocal('withdrawals', INITIAL_WITHDRAWALS));
  const [notifications, setNotifications] = useState<AppNotification[]>(() => getLocal('notifications', INITIAL_NOTIFICATIONS));
  const [reports, setReports] = useState<ContentReport[]>(() => getLocal('reports', INITIAL_REPORTS));
  const [privacy, setPrivacy] = useState<PrivacySettings>(() => getLocal('privacy', DEFAULT_PRIVACY_SETTINGS));

  // Modals & Panels
  const [createModalType, setCreateModalType] = useState<'post' | 'reel' | 'story' | 'product' | null>(null);
  const [searchModalOpen, setSearchModalOpen] = useState<boolean>(false);
  const [walletModalOpen, setWalletModalOpen] = useState<boolean>(false);
  const [adminPanelOpen, setAdminPanelOpen] = useState<boolean>(false);
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; payload: PaymentIntentPayload | null }>({
    isOpen: false,
    payload: null,
  });

  // Call State
  const [activeCall, setActiveCall] = useState<{
    status: 'idle' | 'calling' | 'incoming' | 'connected';
    type: 'voice' | 'video';
    partner: User | null;
    isMuted: boolean;
    isCameraOn: boolean;
    isSpeaker: boolean;
    duration: number;
  }>({
    status: 'idle',
    type: 'video',
    partner: null,
    isMuted: false,
    isCameraOn: true,
    isSpeaker: true,
    duration: 0,
  });

  // Sync state to local storage
  useEffect(() => { setLocal('theme', theme); }, [theme]);
  useEffect(() => { setLocal('isMobileFrame', isMobileFrame); }, [isMobileFrame]);
  useEffect(() => { setLocal('current_user', currentUser); }, [currentUser]);
  useEffect(() => { setLocal('posts', posts); }, [posts]);
  useEffect(() => { setLocal('reels', reels); }, [reels]);
  useEffect(() => { setLocal('stories', stories); }, [stories]);
  useEffect(() => { setLocal('conversations', conversations); }, [conversations]);
  useEffect(() => { setLocal('calls', calls); }, [calls]);
  useEffect(() => { setLocal('communities', communities); }, [communities]);
  useEffect(() => { setLocal('products', products); }, [products]);
  useEffect(() => { setLocal('transactions', transactions); }, [transactions]);
  useEffect(() => { setLocal('withdrawals', withdrawals); }, [withdrawals]);
  useEffect(() => { setLocal('notifications', notifications); }, [notifications]);
  useEffect(() => { setLocal('reports', reports); }, [reports]);
  useEffect(() => { setLocal('privacy', privacy); }, [privacy]);

  // Call timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeCall.status === 'connected') {
      interval = setInterval(() => {
        setActiveCall((prev) => ({ ...prev, duration: prev.duration + 1 }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeCall.status]);

  // Dark mode document class sync
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  const toggleMobileFrame = () => setIsMobileFrame((prev) => !prev);

  // Switch Role / Persona for instant full testing
  const switchUserRole = (role: 'creator' | 'user' | 'admin') => {
    if (role === 'admin') {
      setCurrentUser(ADMIN_USER);
    } else if (role === 'user') {
      const regularUser: User = {
        ...CURRENT_USER,
        id: 'usr_regular',
        role: 'user',
        username: 'karan_fan',
        name: 'Karan K.',
        bio: 'Exploring reels, tech reviews and joining vibrant Indian creator spaces 🌟',
        followersCount: 142,
        followingCount: 310,
        earnings: undefined,
      };
      setCurrentUser(regularUser);
    } else {
      setCurrentUser(CURRENT_USER);
    }
  };

  // Content Actions
  const likePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const isLiked = !p.isLiked;
          return {
            ...p,
            isLiked,
            likesCount: isLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1),
          };
        }
        return p;
      })
    );
  };

  const savePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, isSaved: !p.isSaved } : p))
    );
  };

  const addPost = (postData: Omit<Post, 'id' | 'createdAt' | 'author' | 'userId' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount'>) => {
    const newPost: Post = {
      ...postData,
      id: 'post_' + Date.now(),
      userId: currentUser.id,
      author: currentUser,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      savesCount: 0,
      isLiked: false,
      isSaved: false,
      createdAt: 'Just now',
    };
    setPosts((prev) => [newPost, ...prev]);
    // increment creator profile likes/posts
    setCurrentUser((prev) => ({ ...prev }));
  };

  const unlockExclusivePost = async (postId: string): Promise<boolean> => {
    const post = posts.find((p) => p.id === postId);
    if (!post || !post.exclusivePrice) return false;

    setPaymentModal({
      isOpen: true,
      payload: {
        amountINR: post.exclusivePrice,
        purpose: 'exclusive_post',
        targetId: post.id,
        targetName: `Exclusive Post by @${post.author.username}`,
        paymentMethod: 'upi',
      },
    });
    return true;
  };

  const likeReel = (reelId: string) => {
    setReels((prev) =>
      prev.map((r) => {
        if (r.id === reelId) {
          const isLiked = !r.isLiked;
          return {
            ...r,
            isLiked,
            likesCount: isLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1),
          };
        }
        return r;
      })
    );
  };

  const saveReel = (reelId: string) => {
    setReels((prev) =>
      prev.map((r) => (r.id === reelId ? { ...r, isSaved: !r.isSaved } : r))
    );
  };

  const addReel = (reelData: Omit<Reel, 'id' | 'createdAt' | 'author' | 'userId' | 'viewsCount' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount'>) => {
    const newReel: Reel = {
      ...reelData,
      id: 'reel_' + Date.now(),
      userId: currentUser.id,
      author: currentUser,
      viewsCount: 1,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      savesCount: 0,
      isLiked: false,
      isSaved: false,
      createdAt: 'Just now',
    };
    setReels((prev) => [newReel, ...prev]);
  };

  const reportContent = (contentType: 'reel' | 'post' | 'user' | 'community', targetId: string, reason: string) => {
    const newReport: ContentReport = {
      id: 'rep_' + Date.now(),
      reportedBy: currentUser,
      contentType,
      targetId,
      reason,
      status: 'pending',
      createdAt: 'Just now',
    };
    setReports((prev) => [newReport, ...prev]);
  };

  const addStory = (mediaUrl: string, mediaType: 'image' | 'video', caption?: string, isCloseFriends?: boolean) => {
    const newStory: Story = {
      id: 'story_' + Date.now(),
      userId: currentUser.id,
      author: currentUser,
      mediaUrl,
      mediaType,
      caption,
      createdAt: 'Just now',
      expiresAt: '24h left',
      viewers: [],
      reactions: [],
      isCloseFriendsOnly: isCloseFriends,
      hasViewed: true,
    };
    setStories((prev) => [newStory, ...prev]);
  };

  const viewStory = (storyId: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          const alreadyViewed = s.viewers.some((v) => v.userId === currentUser.id);
          const viewers = alreadyViewed
            ? s.viewers
            : [
                ...s.viewers,
                {
                  userId: currentUser.id,
                  username: currentUser.username,
                  avatar: currentUser.avatar,
                  viewedAt: 'Just now',
                },
              ];
          return { ...s, hasViewed: true, viewers };
        }
        return s;
      })
    );
  };

  const reactToStory = (storyId: string, emoji: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          return {
            ...s,
            reactions: [
              ...s.reactions,
              { userId: currentUser.id, emoji, createdAt: 'Just now' },
            ],
          };
        }
        return s;
      })
    );
  };

  const followUser = (userId: string) => {
    setAllUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const isFollowing = !u.isFollowing;
          return {
            ...u,
            isFollowing,
            followersCount: isFollowing ? u.followersCount + 1 : Math.max(0, u.followersCount - 1),
          };
        }
        return u;
      })
    );
    // Also toggle in currentUser followingCount
    setCurrentUser((prev) => ({
      ...prev,
      followingCount: prev.followingCount + 1,
    }));
  };

  // Messaging Actions
  const sendMessage = (
    convId: string,
    content: string,
    type: ChatMessage['type'] = 'text',
    mediaUrl?: string,
    replyTo?: any
  ) => {
    const newMessage: ChatMessage = {
      id: 'msg_' + Date.now(),
      conversationId: convId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type,
      content,
      mediaUrl,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      replyTo,
      reactions: {},
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === convId) {
          return {
            ...c,
            lastMessage: newMessage,
            updatedAt: newMessage.createdAt,
          };
        }
        return c;
      })
    );

    // Simulate delivered and peer response after 2.5s if talking to another user
    setTimeout(() => {
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === convId && c.lastMessage?.id === newMessage.id) {
            return {
              ...c,
              lastMessage: { ...newMessage, status: 'seen' },
            };
          }
          return c;
        })
      );
    }, 1500);

    // If it's Rohit or Ananya, simulate an automatic friendly reply
    const targetConv = conversations.find((c) => c.id === convId);
    if (targetConv && !targetConv.isGroup) {
      const otherUser = targetConv.members.find((m) => m.id !== currentUser.id);
      if (otherUser) {
        setTimeout(() => {
          const replies = [
            'Awesome! Checking out your reel right now 🚀',
            'That sounds perfect, let me know when you are free!',
            'Got it! Looking forward to the collaboration 🔥',
            'Loved the color grade in that cut! ✨',
          ];
          const autoReply: ChatMessage = {
            id: 'msg_auto_' + Date.now(),
            conversationId: convId,
            senderId: otherUser.id,
            senderName: otherUser.name,
            senderAvatar: otherUser.avatar,
            type: 'text',
            content: replies[Math.floor(Math.random() * replies.length)],
            createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'delivered',
            reactions: {},
          };
          setConversations((prev) =>
            prev.map((c) => {
              if (c.id === convId) {
                return {
                  ...c,
                  lastMessage: autoReply,
                  unreadCount: c.unreadCount + 1,
                  updatedAt: autoReply.createdAt,
                };
              }
              return c;
            })
          );
        }, 3000);
      }
    }
  };

  const deleteMessage = (convId: string, messageId: string) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === convId && c.lastMessage?.id === messageId) {
          return {
            ...c,
            lastMessage: {
              ...c.lastMessage,
              content: 'This message was deleted',
              isDeleted: true,
            },
          };
        }
        return c;
      })
    );
  };

  const reactToMessage = (convId: string, messageId: string, emoji: string) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === convId && c.lastMessage?.id === messageId) {
          return {
            ...c,
            lastMessage: {
              ...c.lastMessage,
              reactions: {
                ...c.lastMessage.reactions,
                [currentUser.id]: emoji,
              },
            },
          };
        }
        return c;
      })
    );
  };

  const createGroup = (name: string, description: string, memberIds: string[]): string => {
    const selectedMembers = allUsers.filter((u) => memberIds.includes(u.id));
    const newGroup: Conversation = {
      id: 'conv_group_' + Date.now(),
      isGroup: true,
      name,
      description,
      avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=300&auto=format&fit=crop&q=80',
      members: [currentUser, ...selectedMembers],
      adminIds: [currentUser.id],
      unreadCount: 0,
      updatedAt: 'Just now',
      lastMessage: {
        id: 'msg_created_' + Date.now(),
        conversationId: 'conv_group_' + Date.now(),
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        type: 'text',
        content: `Created group "${name}"`,
        createdAt: 'Just now',
        status: 'delivered',
        reactions: {},
      },
    };
    setConversations((prev) => [newGroup, ...prev]);
    return newGroup.id;
  };

  // Calling
  const startCall = (partner: User, type: 'voice' | 'video') => {
    setActiveCall({
      status: 'calling',
      type,
      partner,
      isMuted: false,
      isCameraOn: type === 'video',
      isSpeaker: true,
      duration: 0,
    });

    // Simulate recipient pickup after 2 seconds
    setTimeout(() => {
      setActiveCall((prev) => {
        if (prev.status === 'calling') {
          return { ...prev, status: 'connected' };
        }
        return prev;
      });
    }, 2200);
  };

  const answerCall = () => {
    setActiveCall((prev) => ({ ...prev, status: 'connected' }));
  };

  const endCall = () => {
    if (activeCall.partner) {
      const newRecord: CallRecord = {
        id: 'call_' + Date.now(),
        type: activeCall.type,
        direction: 'outgoing',
        partner: activeCall.partner,
        durationSeconds: activeCall.duration,
        createdAt: 'Just now',
        status: activeCall.duration > 0 ? 'completed' : 'missed',
      };
      setCalls((prev) => [newRecord, ...prev]);
    }
    setActiveCall({
      status: 'idle',
      type: 'video',
      partner: null,
      isMuted: false,
      isCameraOn: true,
      isSpeaker: true,
      duration: 0,
    });
  };

  const toggleCallMute = () => setActiveCall((p) => ({ ...p, isMuted: !p.isMuted }));
  const toggleCallCamera = () => setActiveCall((p) => ({ ...p, isCameraOn: !p.isCameraOn }));
  const toggleCallSpeaker = () => setActiveCall((p) => ({ ...p, isSpeaker: !p.isSpeaker }));

  // Communities
  const joinCommunity = (communityId: string) => {
    setCommunities((prev) =>
      prev.map((c) => {
        if (c.id === communityId) {
          const isJoined = !c.isJoined;
          return {
            ...c,
            isJoined,
            membersCount: isJoined ? c.membersCount + 1 : Math.max(0, c.membersCount - 1),
          };
        }
        return c;
      })
    );
  };

  const createCommunity = (comm: Omit<Community, 'id' | 'createdAt' | 'membersCount' | 'postsCount' | 'isJoined' | 'moderators'>) => {
    const newCommunity: Community = {
      ...comm,
      id: 'comm_' + Date.now(),
      createdAt: 'Just now',
      membersCount: 1,
      postsCount: 0,
      isJoined: true,
      moderators: [currentUser.id],
    };
    setCommunities((prev) => [newCommunity, ...prev]);
  };

  // Monetization & Digital Store
  const purchaseProduct = async (product: DigitalProduct): Promise<boolean> => {
    setPaymentModal({
      isOpen: true,
      payload: {
        amountINR: product.priceINR,
        purpose: 'product',
        targetId: product.id,
        targetName: product.title,
        paymentMethod: 'upi',
      },
    });
    return true;
  };

  const sendTipToCreator = async (creator: User, amountINR: number, note?: string): Promise<boolean> => {
    setPaymentModal({
      isOpen: true,
      payload: {
        amountINR,
        purpose: 'tip',
        targetId: creator.id,
        targetName: `Tip for @${creator.username}${note ? ` ("${note}")` : ''}`,
        paymentMethod: 'upi',
      },
    });
    return true;
  };

  const requestWithdrawal = (amountINR: number, upiId: string) => {
    const newReq: WithdrawalRequest = {
      id: 'wth_' + Date.now(),
      userId: currentUser.id,
      user: currentUser,
      amountINR,
      upiId,
      status: 'pending',
      requestedAt: 'Just now',
      note: 'Creator payout transfer',
    };
    setWithdrawals((prev) => [newReq, ...prev]);
    // Deduct from current balance to pending
    if (currentUser.earnings) {
      setCurrentUser((prev) => ({
        ...prev,
        earnings: {
          balance: Math.max(0, (prev.earnings?.balance || 0) - amountINR),
          pendingPayout: (prev.earnings?.pendingPayout || 0) + amountINR,
          totalEarned: prev.earnings?.totalEarned || 0,
        },
      }));
    }
  };

  const approveWithdrawal = (requestId: string) => {
    setWithdrawals((prev) =>
      prev.map((w) => {
        if (w.id === requestId) {
          return {
            ...w,
            status: 'approved',
            processedAt: 'Just now',
          };
        }
        return w;
      })
    );
  };

  const rejectWithdrawal = (requestId: string) => {
    setWithdrawals((prev) =>
      prev.map((w) => {
        if (w.id === requestId) {
          return {
            ...w,
            status: 'rejected',
            processedAt: 'Just now',
          };
        }
        return w;
      })
    );
  };

  const resolveReport = (reportId: string, dismiss = false) => {
    setReports((prev) =>
      prev.map((r) =>
        r.id === reportId ? { ...r, status: dismiss ? 'dismissed' : 'resolved' } : r
      )
    );
  };

  const banUser = (userId: string) => {
    setAllUsers((prev) => prev.filter((u) => u.id !== userId));
  };

  const updatePrivacySettings = (settings: Partial<PrivacySettings>) => {
    setPrivacy((prev) => ({ ...prev, ...settings }));
  };

  const markNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        allUsers,
        currentTab,
        setCurrentTab,
        posts,
        reels,
        stories,
        conversations,
        activeConversation,
        setActiveConversation,
        calls,
        activeCall,
        communities,
        products,
        transactions,
        withdrawals,
        notifications,
        reports,
        privacy,
        theme,
        isMobileFrame,
        onboardingStep,
        createModalType,
        setCreateModalType,
        searchModalOpen,
        setSearchModalOpen,
        walletModalOpen,
        setWalletModalOpen,
        adminPanelOpen,
        setAdminPanelOpen,
        paymentModal,
        setPaymentModal,
        toggleTheme,
        toggleMobileFrame,
        setOnboardingStep,
        switchUserRole,
        likePost,
        savePost,
        addPost,
        unlockExclusivePost,
        likeReel,
        saveReel,
        addReel,
        reportContent,
        addStory,
        viewStory,
        reactToStory,
        followUser,
        sendMessage,
        deleteMessage,
        reactToMessage,
        createGroup,
        startCall,
        answerCall,
        endCall,
        toggleCallMute,
        toggleCallCamera,
        toggleCallSpeaker,
        joinCommunity,
        createCommunity,
        purchaseProduct,
        sendTipToCreator,
        requestWithdrawal,
        approveWithdrawal,
        rejectWithdrawal,
        resolveReport,
        banUser,
        updatePrivacySettings,
        markNotificationsAsRead,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
