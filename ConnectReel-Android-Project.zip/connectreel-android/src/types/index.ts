export type NavTab = 'home' | 'reels' | 'create' | 'chats' | 'communities' | 'profile';

export type UserRole = 'user' | 'creator' | 'admin';

export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  phone?: string;
  avatar: string;
  bio: string;
  role: UserRole;
  isVerified?: boolean;
  followersCount: number;
  followingCount: number;
  totalLikesCount: number;
  isPrivate: boolean;
  interests: string[];
  joinedDate: string;
  isFollowing?: boolean;
  isCloseFriend?: boolean;
  status?: 'online' | 'offline' | 'away';
  lastSeen?: string;
  badge?: string;
  earnings?: {
    balance: number;
    pendingPayout: number;
    totalEarned: number;
  };
}

export interface Post {
  id: string;
  userId: string;
  author: User;
  mediaType: 'image' | 'video' | 'carousel';
  mediaUrls: string[];
  caption: string;
  hashtags: string[];
  location?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  createdAt: string;
  isExclusive?: boolean;
  exclusivePrice?: number;
  hasUnlocked?: boolean;
}

export interface Reel {
  id: string;
  userId: string;
  author: User;
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  audioTrack: {
    title: string;
    artist: string;
    isOriginal: boolean;
    durationSeconds: number;
  };
  hashtags: string[];
  viewsCount: number;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  createdAt: string;
  isTrending?: boolean;
  category: string;
}

export interface Story {
  id: string;
  userId: string;
  author: User;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  caption?: string;
  createdAt: string;
  expiresAt: string;
  viewers: {
    userId: string;
    username: string;
    avatar: string;
    viewedAt: string;
  }[];
  reactions: {
    userId: string;
    emoji: string;
    createdAt: string;
  }[];
  isCloseFriendsOnly?: boolean;
  hasViewed?: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  author: User;
  content: string;
  createdAt: string;
  likesCount: number;
  isLiked?: boolean;
}

export type MessageType = 'text' | 'image' | 'video' | 'voice' | 'doc' | 'payment_request';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  type: MessageType;
  content: string;
  mediaUrl?: string;
  fileName?: string;
  fileSize?: string;
  duration?: number; // for voice
  createdAt: string;
  status: 'sent' | 'delivered' | 'seen';
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
  reactions: {
    [userId: string]: string; // emoji
  };
  isDeleted?: boolean;
}

export interface Conversation {
  id: string;
  isGroup: boolean;
  name?: string;
  avatar?: string;
  description?: string;
  members: User[];
  adminIds?: string[];
  lastMessage?: ChatMessage;
  unreadCount: number;
  updatedAt: string;
  isMuted?: boolean;
}

export interface CallRecord {
  id: string;
  type: 'voice' | 'video';
  direction: 'incoming' | 'outgoing' | 'missed';
  partner: User;
  durationSeconds: number;
  createdAt: string;
  status: 'completed' | 'missed' | 'rejected';
}

export interface Community {
  id: string;
  name: string;
  slug: string;
  description: string;
  bannerUrl: string;
  avatarUrl: string;
  category: string;
  isPrivate: boolean;
  membersCount: number;
  postsCount: number;
  isJoined?: boolean;
  moderators: string[];
  rules: string[];
  createdAt: string;
}

export interface DigitalProduct {
  id: string;
  creatorId: string;
  creator: User;
  title: string;
  description: string;
  coverUrl: string;
  type: 'course' | 'preset' | 'ebook' | 'template';
  priceINR: number;
  salesCount: number;
  rating: number;
  reviewsCount: number;
  hasPurchased?: boolean;
}

export interface CreatorSubscriptionTier {
  id: string;
  creatorId: string;
  title: string;
  pricePerMonthINR: number;
  perks: string[];
  isSubscribed?: boolean;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'earning' | 'withdrawal' | 'tip' | 'purchase' | 'subscription';
  amountINR: number;
  description: string;
  status: 'completed' | 'pending' | 'rejected';
  referenceId: string;
  createdAt: string;
  paymentMethod?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  user: User;
  amountINR: number;
  upiId?: string;
  bankAccount?: {
    accountNumber: string;
    ifsc: string;
    holderName: string;
  };
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  processedAt?: string;
  note?: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  actor: User;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'story_reply' | 'call' | 'tip' | 'withdrawal';
  content: string;
  referenceId?: string;
  createdAt: string;
  isRead: boolean;
}

export interface ContentReport {
  id: string;
  reportedBy: User;
  contentType: 'reel' | 'post' | 'user' | 'community';
  targetId: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface PrivacySettings {
  isPrivateAccount: boolean;
  whoCanMessageMe: 'everyone' | 'following' | 'nobody';
  whoCanCallMe: 'everyone' | 'following' | 'nobody';
  storyPrivacy: 'everyone' | 'following' | 'close_friends';
  lastSeenVisibility: 'everyone' | 'following' | 'nobody';
  onlineStatusVisibility: boolean;
  readReceipts: boolean;
  blockedUserIds: string[];
}
