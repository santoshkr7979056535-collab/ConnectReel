import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.connectreel.app',
  appName: 'ConnectReel',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#0a0a0a'
  },
  server: {
    androidScheme: 'https'
  }
};

export default config;
